title: Mybatis-Plus
date: '2021-06-21 21:13:00'
updated: '2021-08-19 20:34:35'
tags: [Mybatis-Plus]
permalink: /articles/2021/06/21/1624281502473.html
---
**编写项目，初始化项目！使用SpringBoot初始化！**

# 1、导入依赖

```
<!--mybatis-plus-->
​
 <!--mybatis-plus    velocity默认 html模板 -->
        <dependency>
            <groupId>org.apache.velocity</groupId>
            <artifactId>velocity-engine-core</artifactId>
            <version>2.3</version>
        </dependency>
 <!--mybatis-plus     mybatis-plus 是自己开发，并非官方的！-->
        <dependency>
            <groupId>com.baomidou</groupId>
            <artifactId>mybatis-plus-boot-starter</artifactId>
            <version>3.4.3</version>
        </dependency>
        <dependency>
            <groupId>com.baomidou</groupId>
            <artifactId>mybatis-plus-generator</artifactId>
            <version>3.4.1</version>
        </dependency>
​
        <dependency>
            <groupId>org.projectlombok</groupId>
            <artifactId>lombok</artifactId>
        </dependency>
```

**说明：我们使用 mybatis-plus 可以节省我们大量的代码，尽量不要同时导入 mybatis 和 mybatisplus！版本的差异！**

```
# mysql 5 驱动不同 com.mysql.jdbc.Driver 
# mysql 8 驱动不同com.mysql.cj.jdbc.Driver、需要增加时区的配置 serverTimezone=GMT%2B8 
#扫描实体类
mybatis.type-aliases-package=com.ytzl.demo.pojo
#扫描映射文件
mybatis.mapper-locations=classpath:mapper/*.xml
#配置数据库
spring.datasource.url=jdbc:mysql://localhost:3306/picture?useUnicode=true&characterEncoding=utf8&zeroDateTimeBehavior=convertToNull&useSSL=true&serverTimezone=GMT%2B8
spring.datasource.username=root
spring.datasource.password=root
spring.datasource.driver-class-name=com.mysql.cj.jdbc.Driver
​
#sql运行日志
mybatis-plus.configuration.log-impl=org.apache.ibatis.logging.stdout.StdOutImpl
```

# **代码自动生成器**

```
package com.echarts.rjb;
​
​
import com.baomidou.mybatisplus.annotation.DbType;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.core.toolkit.StringPool;
import com.baomidou.mybatisplus.generator.AutoGenerator;
import com.baomidou.mybatisplus.generator.InjectionConfig;
import com.baomidou.mybatisplus.generator.config.*;
import com.baomidou.mybatisplus.generator.config.po.TableInfo;
import com.baomidou.mybatisplus.generator.config.rules.DateType;
import com.baomidou.mybatisplus.generator.config.rules.NamingStrategy;
​
import java.util.ArrayList;
import java.util.List;
​
​
public class cxpCode {
    public static void main(String[] args) {
        //需要构建一个代码自动生成器
        AutoGenerator mpg=new AutoGenerator();
        //配置策略
​
        //1.全局配置
        GlobalConfig gc =new GlobalConfig();
        String projectPath=System.getProperty("user.dir");
        gc.setOutputDir(projectPath+"/src/main/java");
        gc.setAuthor("cxp");
        gc.setOpen(false);//是否打开资源管理器
        gc.setFileOverride(false);//是否覆盖
        gc.setServiceName("%sService");//去service的I前缀
        gc.setIdType(IdType.ID_WORKER);
        gc.setDateType(DateType.ONLY_DATE);
        gc.setSwagger2(false);
        mpg.setGlobalConfig(gc);
​
        //2.设置数据源
        DataSourceConfig dsc = new DataSourceConfig();
        dsc.setUrl("jdbc:mysql://localhost:3306/picture?useUnicode=true&useSSL=false&characterEncoding=utf8");
        // dsc.setSchemaName("public");
        dsc.setDriverName("com.mysql.cj.jdbc.Driver");
        dsc.setUsername("root");
        dsc.setPassword("root");
        dsc.setDbType(DbType.MYSQL);
        mpg.setDataSource(dsc);
​
        //3.包的配置
        PackageConfig pc = new PackageConfig();
        //pc.setModuleName("pic");
        pc.setModuleName(null);//不设置模块名
        pc.setParent("com.echarts.rjb");
        pc.setEntity("pojo");
        pc.setMapper("mapper");
        pc.setService("service");
        pc.setController("controller");
        mpg.setPackageInfo(pc);
​
​
        // 自定义配置--->xml方resources文件夹下创建mapper
        InjectionConfig cfg = new InjectionConfig() {
            @Override
            public void initMap() {
                // to do nothing
            }
        };
        // 如果模板引擎是 velocity（默认）
        String templatePath = "/templates/mapper.xml.vm";
        // 自定义输出配置
        List<FileOutConfig> focList = new ArrayList<>();
        // 自定义配置会被优先输出
        focList.add(new FileOutConfig(templatePath) {
            @Override
            public String outputFile(TableInfo tableInfo) {
                // 自定义输出文件名 ， 如果你 Entity 设置了前后缀、此处注意 xml 的名称会跟着发生变化！！
​
                return projectPath + "/src/main/resources/mapper/"  //+ pc.getModuleName()
                        + "/" + tableInfo.getEntityName() + "Mapper" + StringPool.DOT_XML;
            }
        });
        cfg.setFileOutConfigList(focList);
        mpg.setCfg(cfg);
​
        // 配置模板--->去除dao(mapper)下的xml
        TemplateConfig templateConfig = new TemplateConfig();
        templateConfig.setXml(null);
        mpg.setTemplate(templateConfig);
​
        //4.策略配置
        StrategyConfig strategy = new StrategyConfig();
        strategy.setInclude("author");//设置映射的表名
        strategy.setNaming(NamingStrategy.underline_to_camel);//设置包命名规范下划线转驼峰命名
        strategy.setColumnNaming(NamingStrategy.underline_to_camel);//列名下划线转驼峰命名
        strategy.setEntityLombokModel(true);//自动生成lombok
​
        /*strategy.setLogicDeleteFieldName("deleted");//逻辑删除
        //自动填充
        TableFill gmtCreat = new TableFill("gmt_create", FieldFill.INSERT);
        TableFill gmtModified = new TableFill("gmt_modified", FieldFill.UPDATE);
        ArrayList<TableFill> tableFills=new ArrayList<>();
        tableFills.add(gmtCreat);
        tableFills.add(gmtModified);
        strategy.setTableFillList(tableFills);
​
        //乐观锁
        strategy.setVersionFieldName("version");
        strategy.setRestControllerStyle(true);
        strategy.setControllerMappingHyphenStyle(true);//localhost:8080/hello_id2*/
​
​
        mpg.execute();//执行
​
    }
}
​
```

