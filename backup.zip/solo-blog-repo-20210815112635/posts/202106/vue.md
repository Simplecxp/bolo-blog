title: vue
date: '2021-06-01 21:58:00'
updated: '2021-08-01 11:46:05'
tags: [vue]
permalink: /articles/2021/06/01/1622555910471.html
---
# Vue 1

## 一.邂逅Vue.js

### **1.1认识Vuejs**

* Vue读音
* Vue的渐进式
* Vue的特点

### **1.2安装Vue**

* CDN引入
* 下载引入
* npm安装

1.3Vue的初体验

* Hello Vuejs
  * mustache -->体验Vue响应式
* Vue列表展示
  * v-for
  * 后面给数组追加元素的时候，新的元素也可以在界面中渲染出来
* Vue计数器小案例
  * 事件监听：click-->methods

### 1.4.Vue中的MVVM

### 1.5.创建Vue时，option可以放那些东西

* el:
* data:
* methods:
* 生命周期函数

### 二.插值语法

* mustache语法
* v-once
* v-html
* v-text
* v-pre{{}}
* v-cloak:斗篷

### 三.动态绑定属性

#### 3.1.v-bind绑定基本属性

* v-bind
* :href

#### 3.2.v-bind动态绑定class

* 对象语法：class={类名：Boolean}
* 数组语法：

#### 3.3.v-bind动态绑定style

* 
* 

### 四.计算属性

* 1.firstname+lastname
* 2.books--price

## 创建项目

vue init webpack 项目名

...

## 轮播图

```
<template><!-- 当前展示模板 -->
<!--
  template标签下只能有一个div
 -->
  <div id="app">
    <img src="./assets/logo.png">
    <!-- 文本插值-->
    {{msg}}
    {{number}}
​
    <!--vue指令 v-for : 循环迭代list数组 -->
    <div v-for="(item,index) in list">
      姓名：{{item.name}}
      年龄：{{item.age}}
      index:{{index}}
    </div>
​
    <!-- vue指令 v-if：根据声明的值进行判断-->
    <div v-if="isBig">我是否应该出现(v-if)</div>
    <!-- vue指令 v-show：根据声明的值进行判断-->
    <!-- v-show和v-if 的区别
        1.  v-if :直接控制dom元素是否显隐；
           v-show:控制display样式，none：隐藏 block：显示
        2.  v-if :只有初始条件为真时，才会编译dom元素吗、
           不适用于频繁切换。
           v-show: 是任何条件下都会编译，然后通过display
           控制显隐,但是初始渲染消耗大。
        3.  运行条件少时用v-if
           频繁切换多时用v-show
    -->
    <div v-show="isBig">我是否出现(v-show)</div>
​
​
    <!-- vue指令 v-else
                 v-else-if
    -->
    <div>当前随机数：{{randomNumber}}</div>
    <div v-if="randomNumber>0.5">随机数大于0.5展示</div>
    <div v-else-if="randomNumber>0.2">随机数大于0.2展示</div>
    <div v-else>随机数小于0.2展示</div>
​
    <el-table
          :data="tableData"
          style="width: 100%">
          <el-table-column
            prop="id"
            label="图片标识"
            width="180">
          </el-table-column>
          <el-table-column
            prop="name"
            label="图片标题"
            width="180">
          </el-table-column>
          <el-table-column
            prop="address"
            label="图片地址">
          </el-table-column>
          <el-table-column
            prop="date"
            label="日期">
          </el-table-column>
          <el-table-column label="操作">
                <template slot-scope="scope">
                  <el-button
                    size="mini"
                    @click="handleEdit(scope.$index, scope.row)">编辑</el-button>
                  <el-button
                    size="mini"
                    type="danger"
                    @click="handleDelete(scope.$index, scope.row)">删除</el-button>
                </template>
              </el-table-column>
        </el-table>
        
​
  </div>
​
</template>
​
<script>/* 脚本语言 */
export default {
  name: 'App',
  data(){
    /**
     * vue实例化数据对象，由key/value键值对的形式存储对象，
     * 会将data中的相应对象响应数据变化
     */
    return{
      tableData: [{
                  id: '1',
                  name: '第一个图片',
                  address: '上海市',
                  date: '2016-05-01'
                }, {
                  id: '2',
                  name: '第二个图片',
                  address: '不知道',
                  date: '2016-05-01'
                }, {
                  id: '3',
                  name: '第三个图片',
                  address: '洛阳市',
                  date: '2016-05-01'
                }, {
                  id: '4',
                  name: '第四个图片',
                  address: '河南省',
                  date: '2016-05-01'
                }],
      msg:"HELLO VUE",
      number:1,
      list:[
        {name:"张三",age:"12"},
        {name:"王五",age:"12"},
        {name:"李四",age:"12"}
      ],
      isBig:true,
      randomNumber:Math.random(),//声明随机数
    }
  }
}
</script>
​
<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
​
```

```
<template><!-- 当前展示模板 -->
  <div>
    <!-- <img :src=imgUrl alt=""> -->
    <el-carousel :interval="4000" type="card" height="200px">
        <el-carousel-item v-for="(item,index) in list" :key="index">
          <h3 class="medium"><img :src=item.imgUrl alt=""></h3>
        </el-carousel-item>
      </el-carousel>
  </div>
​
</template>
​
​
​
<script>/* 脚本语言 */
export default {
  name: 'App',
  data(){
    /**
     * vue实例化数据对象，由key/value键值对的形式存储对象，
     * 会将data中的相应对象响应数据变化
     */
    return{
      //imgUrl:"static/pkq.jpg",//图片存放地址
      /* {imgUrl:"static/changan.jpg"},
        {imgUrl:"static/changan.jpg"},
        {imgUrl:"static/changan.jpg"}*/
      list:[
​
      ],//用來接收后台传来的值
    }
  },
  methods:{ //vue方法
    getBannerList(){//获取轮播图list集合
      this.$http.get('static/test.json').then(res =>{//获取当前的数据
        /* 打印*/
        console.info("res=>",res.data.list);
        this.list = res.data.list //赋值
        console.info("app.vue中的list==》"+this.list)
      })
    }
  },
  created() {//进入页面即加载
    this.getBannerList();
  }
}
</script>
​
<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
/* 走马灯 */
 .el-carousel__item h3 {
    color: #475669;
    font-size: 14px;
    opacity: 0.75;
    line-height: 200px;
    margin: 0;
  }
​
  .el-carousel__item:nth-child(2n) {
    background-color: #99a9bf;
  }
​
  .el-carousel__item:nth-child(2n+1) {
    background-color: #d3dce6;
  }
</style>
​
```

```
methods:{ //vue方法
      getMenulist(){
        this.$http.get('static/menu.json').then(res =>{
          console.info("res=>",res.data.menulist);
          this.menulist = res.data.menulist
          console.info("menu中的list==》"+this.menulist)
        }).catch(err=>{
          console.info("报错")
        })
      },
      created() {
        this.getMenulist()
      }
    }
```

导航 轮播图 侧边栏

```
<template><!-- 当前展示模板 -->
  <div id="app" >
    <!-- <el-menu :default-active="activeIndex"class="el-menu-demo" mode="horizontal"  v-for="(item,index) in menulist" :key="index" @select="handleSelect">
      <el-menu-item index="1">{{item.menuname}}</el-menu-item>
    </el-menu>
    <div class="line"></div> -->
​
    <div class="line"></div>
    <el-menu
      class="el-menu-demo"
      mode="horizontal"
      background-color="#545c64"
      text-color="#fff"
      active-text-color="#ffd04b">
      <el-menu-item v-for="(item,index) in menulist" :key="index" index="1">{{item.menuname}}</el-menu-item>
    </el-menu>
    <div style="
    float: left;">
      <el-menu
            default-active="1"
            class="el-menu-vertical-demo"
            @open="handleOpen"
            @close="handleClose"
            background-color="#545c64"
            text-color="#fff"
            active-text-color="#ffd04b">
            <el-submenu index="1">
              <template slot="title">
                <i class="el-icon-location"></i>
                <span>导航一</span>
              </template>
              <el-menu-item-group>
                <template slot="title">分组一</template>
                <el-menu-item index="1-1">选项1</el-menu-item>
                <el-menu-item index="1-2">选项2</el-menu-item>
              </el-menu-item-group>
              <el-menu-item-group title="分组2">
                <el-menu-item index="1-3">选项3</el-menu-item>
              </el-menu-item-group>
              <el-submenu index="1-4">
                <template slot="title">选项4</template>
                <el-menu-item index="1-4-1">选项1</el-menu-item>
              </el-submenu>
            </el-submenu>
            <el-menu-item index="2">
              <i class="el-icon-menu"></i>
              <span slot="title">导航二</span>
            </el-menu-item>
            <el-menu-item index="3" disabled>
              <i class="el-icon-document"></i>
              <span slot="title">导航三</span>
            </el-menu-item>
            <el-menu-item index="4">
              <i class="el-icon-setting"></i>
              <span slot="title">导航四</span>
            </el-menu-item>
          </el-menu>
    </div>
    <!-- <img :src=imgUrl alt=""> -->
    <el-carousel :interval="4000" type="card" height="200px">
        <el-carousel-item v-for="(item,index) in list" :key="index">
          <h3 class="medium"><img :src=item.imgUrl alt=""></h3>
        </el-carousel-item>
      </el-carousel>
  </div>
​
</template>
​
​
​
<script>/* 脚本语言 */
export default {
  name: 'App',
  data(){
    /**
     * vue实例化数据对象，由key/value键值对的形式存储对象，
     * 会将data中的相应对象响应数据变化
     */
    return{
​
      menulist:[],
      list:[]
​
    };
  },
  methods:{ //vue方法
    getMenuList(){//获取轮播图list集合
    this.$http.get('static/test.json').then(res =>{
      console.info("bannerlist",res.data.list);
      this.list=res.data.list
    }),
      this.$http.get('static/menu.json').then(res =>{//获取当前的数据
        /* 打印*/
        console.info("res=>",res.data.menulist);
        this.menulist = res.data.menulist //赋值
      }).catch(err=>{
        console.info("error");
      })
    }
  },
  created() {//进入页面即加载
    this.getMenuList();
  }
​
}
</script>
​
<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
/* 走马灯 */
 .el-carousel__item h3 {
    color: #475669;
    font-size: 14px;
    opacity: 0.75;
    line-height: 200px;
    margin: 0;
  }
​
  .el-carousel__item:nth-child(2n) {
    background-color: #99a9bf;
  }
​
  .el-carousel__item:nth-child(2n+1) {
    background-color: #d3dce6;
  }
  .el-menu-demo{
    display: flex;
    justify-content: center;
  }
</style>
​
```

## vue生命周期

创建，挂载，运行，销毁

```
<template>
  <div id="app">
    {{msg}}
    <div @click="show()"></div>
    <div @click="updateData()">修改</div>
  </div>
</template>

<script>
export default {
  name: 'App',
  data(){
    return{
      msg:"hello"
    }
  },
  methods:{ //vue 方法
    show(){
      console.info("执行了vue的show方法")
    },
    updateData(){
      this.msg="Goodbye"
    }

  },
  beforeCreate() {
    /**
     * 第一个生命周期
     * data和methods中的所有数据都没有进行初始化
     */
     console.info("beforeCreate========")
     console.info("msg",this.msg)
     this.show()
     console.info("beforeCreate========")
  },
  created() {
    /**
     * 第二个生命周期
     * 证明data和methods已经被初始化，才能被调用
     */
    console.info("created========")
    console.info("msg",this.msg)
    this.show()
    console.info("created========")
  },
  /**
   * 表示开始编译模板，但是是在内存中编译模板
   * 并没有将模板挂载到整个vue页面进行显示
   */
  beforeMount(){
    /**
     * 第三个生命周期
     * 表示模板已经在内存中编译完成，但是并没有把模板
     * 渲染到页面中，也就是页面中的元素，还是没有被替换过来
     */
    console.info("beforeMount========")
    console.info(document.getElementById("app").innerText)
    console.info("beforeMount========")
  },
  mounted() {
    /**
     * 第四个生命周期
     * 表示已经被真实挂载到了页面中
     * 用户可以看到已经被渲染好的页面。
     */
    console.info("mounted========")
    console.info(document.getElementById("app").innerText)
    console.info("mounted========")
  },
  /* 从一到四是我们vue生命周期的第一个大类（创建）*/
  beforeUpdate() {
    /**
     * 第五个生命周期
     * 只有data数据更新时，才会进入update生命周期
     * 这个时候data实例化对象的数据已经被更新但是页面上的数据还没有进行更新
     */
    console.info("beforeupdate=======")
    console.info("app页面上的数据"+document.getElementById("app").innerText)
    console.info("data实例化的数据"+this.msg)
    console.info("beforeupdate=======")
  },
  updated() {
    /**
     * 第六个生命周期
     * 页面和data数据已经保持同步更新
     */
    console.info("updated=======")
    console.info("app页面上的数据"+document.getElementById("app").innerText)
    console.info("data实例化的数据"+this.msg)
    console.info("updated=======")
  },
  /* 5-6是vue生命周期的第二大类（运行），只有data数据改变时才会进入此生命周期*/
  beforeDestroy() {
    /**
     * 第七个生命周期
     * 没有进行真正的销毁，data数据，methods，过滤器等等都还是处于可用状态
     */
    
  },
  deactivated() {
    /**
     * 第八个生命周期
     * 已经被完全销毁，data等都已不可用
     */
  
  }
  /* 7-9 是vue生命周期的第三大类（销毁）*/
  /**
   * 什么是vue的生命周期？？？？？
   *  从vue创建，运行，到销毁的期间，总是伴随各式各样的事件，这些事件统称为生命周期
   */
}

​
</script>
​
<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
​
```

