title: SpringBoot拦截器
date: '2021-06-05 21:44:19'
updated: '2021-08-19 20:34:57'
tags: [SpringBoot]
permalink: /articles/2021/06/21/1624283059389.html
---
# SpringBoot拦截器

```
package com.abc.monster.config;
​
import com.abc.monster.pojo.User;
import org.springframework.web.servlet.HandlerInterceptor;
​
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
​
public class LoginInterceptor implements HandlerInterceptor {
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
​
​
        //   System.out.println("执行了TestInterceptor的preHandle方法");
        try {
            //统一拦截（查询当前session是否存在user）(这里user会在每次登陆成功后，写入session)
            User user=(User)request.getSession().getAttribute("loginuser");
            if(user!=null){
                return true;
            }
            response.sendRedirect("/login");
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;//如果设置为false时，被请求时，拦截器执行到此处将不会继续操作
        //如果设置为true时，请求将会继续执行后面的操作
    }
}
​
```

```
package com.abc.monster.config;
​
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
​
@Configuration //注册一个拦截器,相当于applicationContext-mvc.xml配置
public class InterceptorConfig implements WebMvcConfigurer {
    @Override
    public void addInterceptors(InterceptorRegistry registry) {
​
        //定义需要拦截的路径
        String [] addPathPatterns = {
                "/admin",
                "/admin/post/*",
                "/admin/comment/*"
        };
​
        //定义不需要拦截的路径
        String [] excludePathPatterns = {
                "/login"
​
        };
​
        registry.addInterceptor(new LoginInterceptor())
                .addPathPatterns(addPathPatterns)
                .excludePathPatterns(excludePathPatterns);
    }
}
​
```

