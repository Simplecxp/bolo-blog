title: Thymeleaf整合SpringBoot
date: '2021-06-21 21:13:00'
updated: '2021-06-21 21:13:00'
tags: [Thymeleaf]
permalink: /articles/2021/06/21/1624282611881.html
---
 

**在pom.xml文件引入thymeleaf**

```
<!--在pom.xml文件引入thymeleaf-->
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-thymeleaf</artifactId>
        </dependency>
```

**在application.properties（application.yml）文件中配置thymeleaf**

```
#可以不写使用默认
#  thymeleaf:
#    prefix: classpath:/templates/
#    suffix: .html
#    mode: HTML5
#    cache: false
#    encoding: utf-8
​
```

**新建编辑控制层代码HelloController，在request添加了name属性，返回到前端hello.html再使用thymeleaf取值显示。**

```
​
    @GetMapping("/login")
    public String toLogin(HttpServletRequest request, Model model){
        model.addAttribute("user",new Student(1,"男",12));
​
​
```

**新建编辑模板文件，在resources文件夹下的templates目录，用于存放HTML等模板文件，在这新增hello.html，添加如下代码。**

```
<p th:text="'hello, ' + ${name} + '!'" />
```

***切记：使用Thymeleaf模板引擎时，必须在html文件上方添加该行代码使用支持Thymeleaf***

```
<html lang="en" xmlns:th="http://www.thymeleaf.org">
```

