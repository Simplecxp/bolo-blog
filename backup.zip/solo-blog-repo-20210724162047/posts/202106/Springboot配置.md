title: Springboot配置
date: '2021-06-21 21:13:00'
updated: '2021-06-21 21:13:00'
tags: [SpringBoot]
permalink: /articles/2021/06/21/1624282840995.html
---
# 1.web配置

## 1.banner更换

创建Banner文件 src/main/resource/banner.txt

```
​
${AnsiColor.BRIGHT_YELLOW}
  ____ ___  _________
_/ ___\\  \/  /\____ \
\  \___ >    < |  |_> >
 \___  >__/\_ \|   __/
     \/      \/|__|
${AnsiColor.BRIGHT_RED}
Application Version: ${application.version}${application.formatted-version}
Spring Boot Version: ${spring-boot.version}${spring-boot.formatted-version}
```

从上面的内容中可以看到，还使用了一些属性设置：

* ${AnsiColor.BRIGHT_RED}：设置控制台中输出内容的颜色，可以自定义，具体参考org.springframework.boot.ansi.AnsiColor
* ${application.version}：用来获取MANIFEST.MF文件中的版本号，这就是为什么要在Application.java中指定 SpringVersion.class
* {application.formatted-version}：格式化后的{application.version}版本信息
* ${spring-boot.version}：Spring Boot的版本号
* {spring-boot.formatted-version}：格式化后的{spring-boot.version}版本信息

## 2.自定义欢迎页

默认回去static中找index.html

```
classpath:/static/index.html 
​
classpath:/public/index.html
```

## **3.自定义favico**

浏览器左上角的图标可以放在静态资源下static中，

## **4.其他的服务器配置如jetty**

在某个博客看到改Jetty的好处，也真是我现在开发的项目后面要用长连接

好处：

1. Jetty适合长连接应用，就是聊天类的长连接
2. Jetty更轻量级。这是相对Tomcat而言的。
3. jetty更灵活，体现在其可插拔性和可扩展性，更易于开发者对Jetty本身进行二次开发，定制一个适合自身需求的Web Server。
4. 使用Jetty，需要在spring-boot-starter-web排除spring-boot-starter-tomcat，因为SpringBoot默认使用tomcat对于配置内置服务器的springBoot，都必定会配置

```
<dependency> 
<groupId>org.springframework.boot</groupId> 
<artifactId>spring-boot-starter-web</artifactId> 
</dependency>
```

以上配置springBoot的启动web服务器，但默认是Tomcat

所以呢，要配置为jetty要去掉默认tomcat配置

```
<dependency> 
<groupId>org.springframework.boot</groupId> 
<artifactId>spring-boot-starter-web</artifactId> 
    <exclusions> 
        <exclusion> 
            <groupId>org.springframework.boot</groupId> 
            <artifactId>spring-boot-starter-tomcat</artifactId> 
        </exclusion> 
    </exclusions> 
</dependency>
```

并且加上jetty启动

```
<dependency> 
<groupId>org.springframework.boot</groupId> 
<artifactId>spring-boot-starter-jetty</artifactId> 
</dependency>
```

## **5.资源定义**

```
classpath:/META-INF/resources/ 
classpath:/resources/ 
classpath:/static/ 
classpath:/public/
```

第一种：在配置文件中进行配置

```
#静态资源访问路径 
​
spring.mvc.static-path-pattern=/** 
​
#静态资源映射路径 
​
spring.resources.static-locations=classpath:/
```

第二种：通过编程进行设置

```
@Configuration 
public class MvcConfig extends WebMvcConfigurerAdapter { 
    @Override 
    public void addResourceHandlers(ResourceHandlerRegistry registry) { 
​
    // 这里之所以多了一"/",是为了解决打war时访问不到问题 
    registry.addResourceHandler("/**").addResourceLocations("/","classpath:/"); 
    } 
}
```

## **6.配置错误页**

在static目录下新建error目录

放入对应的错误页面就行了如404.html 500.html

## **7.https配置**

**使用*jdk自带的* keytools** **创建证书**

打开cmd窗口,输入如下命令

```
keytool -genkey -alias tomcat -keyalg RSA -keystore ./server.keystor
```

按照提示进行操作

创建完成后,可在用户根目录查看生成的keystore文件

**将上一步生成的*keystone*文件复制到项目的根目录**,在application.yml添加如下配置

```
server:
  port: 443
  ssl:
    key-store: server.keystore
    key-alias: tomcat
    key-store-password: cxp666
    key-store-type: JKS
```

因为我们的证书不是专业机构提供的，而是自己搞的，所以会显示不安全

springboot不能提供http和https两种请求同事存在，所有需要配几个bean实现

**http访问自动转https访问**

向spring容器中注入两个Bean,代码如下

```
package com.abc.studyspringboot.config;
​
import org.apache.catalina.Context;
import org.apache.catalina.connector.Connector;
import org.apache.tomcat.util.descriptor.web.SecurityCollection;
import org.apache.tomcat.util.descriptor.web.SecurityConstraint;
import org.springframework.boot.web.embedded.tomcat.TomcatServletWebServerFactory;
import org.springframework.context.annotation.Bean;
​
/**
 * 因为我们的证书不是专业机构提供的，而是自己搞的，所以会显示不安全
 * springboot不能提供http和https两种请求同事存在，所有需要配几个bean实现
 * http访问自动转https访问
 * 向spring容器中注入两个Bean,代码如下
 */
public class HttpsConfig {
    @Bean
    public Connector connector() {
        Connector connector = new Connector("org.apache.coyote.http11.Http11NioProtocol");
        connector.setScheme("http");
        connector.setPort(80);
        connector.setSecure(false);
        connector.setRedirectPort(443);
        return connector;
    }
    @Bean
    public TomcatServletWebServerFactory tomcatServletWebServerFactory (Connector connector){
        TomcatServletWebServerFactory tomcat = new TomcatServletWebServerFactory() {
            @Override
            protected void postProcessContext(Context context) {
                SecurityConstraint securityConstraint = new SecurityConstraint();
                securityConstraint.setUserConstraint("CONFIDENTIAL");
                SecurityCollection collection = new SecurityCollection();
                collection.addPattern("/*");
                securityConstraint.addCollection(collection);
                context.addConstraint(securityConstraint);
            }
        };
        tomcat.addAdditionalTomcatConnectors(connector);
        return tomcat;
    }
}
​
```

其次在这里设置http的监听端口为80端口,http默认端口,这样在访问的时候也可以不用带上端口号. 完成

以上配置后,访问 [http://localhost](http://localhost) 即可自动跳转为 [https://localhost](https://localhost)

## **8.打包**

**jar包**

**war包**

标志打包为war

<packaging>war</packaging>

```
<packaging>war</packaging>
​
    <properties>
        <java.version>1.8</java.version>
    </properties>
    <dependencies>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-web</artifactId>
            <!--以上配置springBoot的启动web服务器，但默认是Tomcat
            所以呢，要配置为jetty要去掉默认tomcat配置-->
            <exclusions>
                <exclusion>
                    <groupId>org.springframework.boot</groupId>
                    <artifactId>spring-boot-starter-tomcat</artifactId>
                </exclusion>
            </exclusions>
        </dependency>
        <!--打包不用，编译要-->
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-tomcat</artifactId>
            <scope>provided</scope>
        </dependency>
        <!--加上jetty启动-->
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-jetty</artifactId>
        </dependency>
​
        <dependency>
            <groupId>mysql</groupId>
            <artifactId>mysql-connector-java</artifactId>
            <scope>runtime</scope>
        </dependency>
        <dependency>
            <groupId>org.projectlombok</groupId>
            <artifactId>lombok</artifactId>
            <optional>true</optional>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-test</artifactId>
            <scope>test</scope>
        </dependency>
    </dependencies>
​
    <build>
        <plugins>
            <plugin>
                <groupId>org.springframework.boot</groupId>
                <artifactId>spring-boot-maven-plugin</artifactId>
                <configuration>
                    <excludes>
                        <exclude>
                            <groupId>org.projectlombok</groupId>
                            <artifactId>lombok</artifactId>
                        </exclude>
                    </excludes>
                </configuration>
            </plugin>
        </plugins>
    </build>
​
</project>
```

```
package com.abc.studyspringboot.config;
​
import org.springframework.boot.SpringApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.stereotype.Component;
​
/*打war包配置*/
@Component
public class ServletInitializer extends SpringBootServletInitializer {
    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
        return builder.sources(SpringApplication.class);
    }
}
```

## 9.启动系统任务

有两个接口CommandLineRunner和ApplicationRunner，实现了这两项接口的类会在系统启动后自动

调用执行run方法

```
package com.abc.studyspringboot.config;
​
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
​
@Component
@Order(1)
public class commandRunner implements CommandLineRunner {
​
    @Override
    public void run(String... args) throws Exception {
        System.out.println("1--------------");
    }
}
​
@Component
@Order(2)
public class commandRunner2 implements CommandLineRunner {
    @Override
    public void run(String... args) throws Exception {
        System.out.println("2--------------");
    }
}
​
```

## 10.SpringBoot Profile多环境配置

```
​
```

**多Profile文件**

我们在主配置文件编写的时候，文件名可以是 application-{profile}.properties/yml 例如：

application-dev.yml

application-prod.yml

application-test.yml

默认使用application.properties的配置;

**yml支持多文档块方式**

```
spring:
  profiles:
    active: dev #指定使用哪个环境
---
server:
  port: 8082
spring:
  profiles: dev
---
server:
  port: 8083
spring:
  profiles: test
---
server:
  port: 8084
spring:
  profiles: prod
​
​
```

**激活指定Profile**

在配置文件中指定 spring.profiles.active=dev

命令行：java -jar spring-boot-02-config-0.0.1-SNAPSHOT.jar --spring.profiles.active=dev;

可以直接在测试的时候，配置传入命令行参数

虚拟机参数：-Dspring.profiles.active=dev

