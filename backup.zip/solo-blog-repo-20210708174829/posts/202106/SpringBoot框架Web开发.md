title: Spring Boot 框架 Web 开发
date: '2021-06-03 21:13:00'
updated: '2021-06-21 21:48:07'
tags: [SpringBoot]
permalink: /articles/2021/06/21/1624282382407.html
---
## **3.1Spring Boot** **集成** **MyBatis**

项目名称：002-springboot-web-mybatis

### **3.1.1** **案例思路**

通过 SpringBoot +MyBatis 实现对数据库学生表的查询操作

数据库参考：springboot.sql 脚本文件

### **3.1.2** **实现步骤**

#### **（1） 准备数据库**

启动 mySQL 服务器

创建新的数据库 springboot-01，指定数据库字符编码为 utf-8

![011.png](https://b3logfile.com/file/2021/06/01-1-692ecf68.png)

向表中插入数据

![012.png](https://b3logfile.com/file/2021/06/01-2-5065234a.png)

#### （2）创建002-springboot-web-mybatis项目

#### （3） 在 pom.xml 中添加相关 jar 依赖

```
<dependencies>
​
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-web</artifactId>
        </dependency>
        <!--MyBatis 整合 SpringBoot 的起步依赖-->
        <dependency>
            <groupId>org.mybatis.spring.boot</groupId>
            <artifactId>mybatis-spring-boot-starter</artifactId>
            <version>2.1.4</version>
        </dependency>
        <!--MySQL 的驱动依赖-->
        <dependency>
            <groupId>mysql</groupId>
            <artifactId>mysql-connector-java</artifactId>
            <scope>runtime</scope>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-test</artifactId>
            <scope>test</scope>
        </dependency>
    </dependencies>
​
    <build>
        <plugins>
            <plugin>
                <groupId>org.springframework.boot</groupId>
                <artifactId>spring-boot-maven-plugin</artifactId>
            </plugin>
        </plugins>
​
        <resources>
            <resource>
                <directory>src/main/java</directory>
                <includes>
                    <include>**/*.xml</include>
                </includes>
            </resource>
        </resources>
    </build>
```

#### （4） 在 Springboot 的核心配置文件 application.properties 中配置数据源

注意根据自己数据库的信息修改以下内容

```
​
#配置内嵌 Tomcat 端口号
server.port=9090
#配置项目上下文根
server.servlet.context-path=/002-springboot-web-mybatis
#配置数据库的连接信息
#注意这里的驱动类有变化
spring.datasource.driver-class-name=com.mysql.cj.jdbc.Driver
spring.datasource.url=jdbc:mysql://127.0.0.1:3306/springboot-01?useUnicode=true&characterEncoding=utf-8&useSSL=false&serverTimezone=GMT
spring.datasource.username=root
spring.datasource.password=root
​
# 定义包别名，使用pojo时可以直接使用pojo的类型名称不用加包名
mybatis.type-aliases-package=com.abc.springboot.pojo
```

#### （5） 开发代码

1.创建包pojo 并创建实体类Student

```
public class Student {
    private int id;
    private String name;
    private int age;
​
    public Student() {
    }
​
    public Student(String name, int age) {
        this.name = name;
        this.age = age;
    }
​
    public Student(int id, String name, int age) {
        this.id = id;
        this.name = name;
        this.age = age;
    }
    //...省略get/set方法
```

2.创建包controller 并创建StudentController类 编写代码

```
@Controller
public class StudentController {
    @Autowired
    StudentService studentService;
    @RequestMapping( "/springBoot/student")
    public @ResponseBody Object student() {
        Student student = studentService.queryStudentById(1);
        return student;
    }
}
```

3.在 service 包下创建 service 接口并编写代码

```
public interface StudentService {
​
    Student queryStudentById(int id);
}
​
```

4.在 service.impl 包下创建 service 接口并编写代码

```
@Service
public class StudentServiceImpl implements StudentService{
​
    @Autowired
    StudentMapper studentMapper;
​
    @Override
    public Student queryStudentById(int id) {
        return studentMapper.queryStudentById(id);
    }
}
​
```

5.创建包Mapper并创建StudentMapper接口 编写代码

@Mapper 作用：mybatis 自动扫描数据持久层的映射文件及 DAO 接口的关系

```
@Mapper//@Mapper 作用：mybatis 自动扫描数据持久层的映射文件及 DAO 接口的关系
public interface StudentMapper {
    Student queryStudentById(int id);
}
```

6.在Mapper包下创建StudentMapper.xml 并编写代码

```
<?xml version='1.0' encoding='UTF-8'?>
<!DOCTYPE mapper PUBLIC "-//mybatis.org//DTD Mapper 3.0//EN" "http://mybatis.org/dtd/mybatis-3-mapper.dtd">
<mapper namespace="com.abc.springboot.Mapper.StudentMapper">
    <resultMap id="Student" type="student">
        <id column="id" property="id"/>
        <result column="name" property="name"/>
        <result column="age" property="age"/>
​
    </resultMap>
​
    <select id="queryStudentById">
        select * from student where id=#{id}
    </select>
</mapper>
```

**注意：默认情况下，Mybatis 的 xml 映射文件不会编译到 target 的 class 目录下，所以需要在 pom.xml 文件中配置 resource**

```
<resources>
            <resource>
                <directory>src/main/java</directory>
                <includes>
                    <include>**/*.xml</include>
                </includes>
            </resource>
        </resources>
```

#### （6） 启动 Application 应用，浏览器访问测试运行

![013.png](https://b3logfile.com/file/2021/06/01-3-0d94fd2c.png)

### **3.1.3 DAO** **其它开发方式**

#### （1）在 运 行 的 主 类 上 添 加 注 解 包 扫 描

**@MapperScan("com.abc.springboot.mapper")**

1.注释掉 StudentMapper 接口上的@Mapper 注解

2.在运行主类 Application 上加@MapperScan("com.abc.springboot.mapper")

```
@SpringBootApplication
@MapperScan("com.abc.springboot.mapper")
public class Application {
```

**或**

```
@SpringBootApplication
//Mybatis 提供的注解：扫描数据持久层的 mapper 映谢配置文件,DAO 接口上就不用加@Mapper
//basePackages 通常指定到数据持久层包即可
@MapperScan(basePackages = "com.abc.springboot.mapper")
public class Application {
```

测试运行

#### **（2）将接口和映射文件分开**

因为 SpringBoot 不能自动编译接口映射的 xml 文件，还需要手动在 pom 文件中指定，所以有的公司直接将映射文件直接放到 resources 目录下

➢ 在 resources 目录下新建目录 mapper 存放映射文件，将 StudentMapper.xml 文件移到 resources/mapper 目录下

➢ 在 application.properties 配置文件中指定映射文件的位置，这个配置只有接口和映射文件不在同一个包的情况下，才需要指定

```
# 指定 Mybatis 映射文件的路径
mybatis.mapper-locations=classpath:mapper/*.xml
```

## 3.2Spring Boot 事务支持

Spring Boot 使用事务非常简单，底层依然采用的是 Spring 本身提供的事务管理

➢ 在入口类中使用注解 @EnableTransactionManagement 开启事务支持

➢ 在访问数据库的 Service 方法上添加注解 @Transactional 即可

#### **3.2.1** **案例思路**

通过 SpringBoot +MyBatis 实现对数据库学生表的更新操作，在 service 层的方法中构建异常，查看事务是否生效

#### **3.2.2** **实现步骤**

**（1）在** **StudentController** **中添加更新学生的方法**

```
//在 StudentController 中添加更新学生的方法
    @RequestMapping("/springBoot/modify")
    public @ResponseBody Object modifyStudent(){
        int count=0;
        try {
            Student student=new Student();
            student.setId(1);
            student.setName("Jack");
            student.setAge(20);
            count = studentService.updateByPrimaryKeySelective(student);
        }catch (Exception e){
            e.printStackTrace();
            return "fail";
        }
        return count;
    }
```

**（2）在** **StudentService** **接口中添加更新学生方法**

```
int updateByPrimaryKeySelective(Student student);
```

##### （3）在 StudentServiceImpl 接口实现类中对更新学生方法进行实现，并构建一个异常，同时在该方法上加@Transactional 注解

```
@Override
    @Transactional //添加此注解说明该方法添加的事务管理
    public int updateByPrimaryKeySelective(Student student) {
        int updateCount=studentMapper.updateByPrimaryKeySelective(student);
        System.out.println("更新结果："+updateCount);
​
        //在此构造一个除数为 0 的异常，测试事务是否起作用
        int a= 10/0;
​
        return updateCount;
    }
```

##### （4）在 Application类上加@EnableTransactionManagement开启事务支持

@EnableTransactionManagement 可选，但是业务方法上必须添加@Transactional 事务才生效

```
@SpringBootApplication
@MapperScan(basePackages = "com.abc.springboot.pojo")
@EnableTransactionManagement //开启事务支持(可选项，但@Transactional 必须添加)
public class Application {
```

**启动 Application，通过浏览器访问进行测试**

![015.png](https://b3logfile.com/file/2021/06/01-5-1b72fef9.png)

**控制台**

![014.png](https://b3logfile.com/file/2021/06/01-4-f9a9070f.png)

##### （5）注释掉 StudentServiceImpl 上的@Transactional 测试

**数据库的数据被更新**![016.png](https://b3logfile.com/file/2021/06/01-6-eff3f8b6.png)

## **3.3Spring Boot** 下的**Spring MVC**

Spring Boot 下的 Spring MVC 和之前的 Spring MVC 使用是完全一样的，主要有以下注解

#### **@Controller**

**Spring MVC 的注解，处理 http 请求**

#### **@RestController**

Spring 4 后新增注解，是@Controller 注解功能的增强是 @Controller 与@ResponseBody 的组合注解

如果一个 Controller 类添加了@RestController，那么该 Controller 类下的所有方法都相当于添加了@ResponseBody 注解

用于返回字符串或 json 数据

**案例：**

➢ 创建 MyRestController 类，演示@RestController 替代@Controller + @ResponseBody

```
@RestController
public class MyRestController {
 @Autowired
StudentService studentService;
 @RequestMapping("/boot/stu")
 public Object stu(){
 return studentService.getStudentById(1);
 }
}
```

➢ 启动应用，浏览器访问测试

[http://localhost:9090/002-springboot-web-mybatis/boot/stu](http://localhost:9090/002-springboot-web-mybatis/boot/stu)

```
{
  "id": 1,
  "name": "Jack",
  "age": 20
}
```

#### **@RequestMapping**（常用）

支持 Get 请求，也支持 Post 请求

#### **@GetMapping**

RequestMapping 和 Get 请求方法的组合

只支持 Get 请求

Get 请求主要用于查询操作

#### **@PostMapping**

RequestMapping 和 Post 请求方法的组合

只支持 Post 请求

Post 请求主要用户新增数据

#### **@PutMapping**

RequestMapping 和 Put 请求方法的组合

只支持 Put 请求

Put 通常用于修改数据

#### **@DeleteMapping**

RequestMapping 和 Delete 请求方法的组合

只支持 Delete 请求

通常用于删除数据

### **综合案例**

项目名称：003-springboot-springmvc 项目集成 springmvc

项目作用：演示常见的 SpringMVC 注解

**创建一个 MVCController，里面使用上面介绍的各种注解 接收不同的请求**

```
/**
* 该案例主要演示了使用 Spring 提供的不同注解接收不同类型的请求
*/
//RestController 注解相当于加了给方法加了@ResponseBody 注解，所以是不能跳转页面的，
只能返回字符串或者 json 数据
@RestController
public class MVCController {
 @GetMapping(value = "/query")
 public String get() {
 return "@GetMapping 注解,通常查询时使用";
 }
 @PostMapping(value = "/add")
 public String add() {
 return "@PostMapping 注解，通常新增时使用";
 }
 @PutMapping(value = "/modify")
 public String modify() {
 return "@PutMapping 注解，通常更新数据时使用";
 }
 @DeleteMapping(value = "/remove")
 public String remove() {
 return "@DeleteMapping 注解，通常删除数据时使用";
 } 
}
```

**启动应用，在浏览器中输入不同的请求进行测试**

[http://localhost:8080/query](http://localhost:8080/query)

@GetMapping 注解,通常查询时使用

## **3.4Spring Boot** **实现** **RESTful**

### **3.4.1** **认识** **RESTFul**

**REST**（英文：**Representational State Transfer**，简称**REST**）

```
一种互联网软件架构设计的风格，但它并不是标准，它只是提出了一组客户端和服务器
```

交互时的架构理念和设计原则，基于这种理念和原则设计的接口可以更简洁，更有层次，REST

这个词，是 Roy Thomas Fielding 在他 2000 年的博士论文中提出的。

```
任何的技术都可以实现这种理念，如果一个架构符合 REST 原则，就称它为 RESTFul 架构

比如我们要访问一个 http 接口：[http://localhost:8080/boot/order?id=1021&amp;status=1](http://localhost:8080/boot/order?id=1021&status=1)

采用 RESTFul 风格则 http 地址为：[http://localhost:8080/boot/order/1021/1](http://localhost:8080/boot/order/1021/1)
```

### **3.4.2 Spring Boot** **开发** **RESTFul**

**Spring boot 开发 RESTFul 主要是几个注解实现**

#### **@PathVariable**

获取 url 中的数据

**该注解是实现** **RESTFul** **最主要的一个注解**

#### **@PostMapping**

接收和处理 Post 方式的请求

#### **@DeleteMapping**

接收 delete 方式的请求，可以使用 GetMapping 代替

#### **@PutMapping**

接收 put 方式的请求，可以用 PostMapping 代替

#### **@GetMapping**

接收 get 方式的请求

### **3.4.3** **案例：使用** **RESTful** **风格模拟实现对学生的增删改查操作**

项目名称：004-springboot-restful

该项目集成了 MyBatis、spring、SpringMVC，通过模拟实现对学生的增删改查操作

**pom.xml** **文件添加内容如下**

```
<dependencies>
        <!--SpringBoot 框架 web 项目起步依赖-->
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-web</artifactId>
        </dependency>
​
        <!--MyBatis 集成 SpringBoot 框架起步依赖-->
        <dependency>
            <groupId>org.mybatis.spring.boot</groupId>
            <artifactId>mybatis-spring-boot-starter</artifactId>
            <version>2.0.1</version>
        </dependency>
        <!--MySQL 驱动-->
        <dependency>
            <groupId>mysql</groupId>
            <artifactId>mysql-connector-java</artifactId>
        </dependency>
​
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-test</artifactId>
            <scope>test</scope>
        </dependency>
​
​
​
        <!--MyBatis-Plus代码生成器需要的依赖，开始-->
        <dependency>
            <groupId>com.baomidou</groupId>
            <artifactId>mybatis-plus-boot-starter</artifactId>
            <version>3.4.2</version>
        </dependency>
​
        <dependency>
            <groupId>com.baomidou</groupId>
            <artifactId>mybatis-plus-generator</artifactId>
            <version>3.1.2</version>
        </dependency>
​
        <dependency>
            <groupId>org.apache.velocity</groupId>
            <artifactId>velocity-engine-core</artifactId>
            <version>2.2</version>
        </dependency>
​
        <dependency>
            <groupId>org.projectlombok</groupId>
            <artifactId>lombok</artifactId>
        </dependency>
        <!--MyBatis-Plus代码生成器需要的依赖，结束-->
    </dependencies>
​
    <build>
        <!--指定配置资源的位置-->
        <resources>
            <resource>
                <directory>src/main/java</directory>
                <includes>
                    <include>**/*.xml</include>
                </includes>
            </resource>
        </resources>
​
        <plugins>
            <plugin>
                <groupId>org.springframework.boot</groupId>
                <artifactId>spring-boot-maven-plugin</artifactId>
            </plugin>
        </plugins>
​
    </build>
```

**application.yml** **核心配置文件**

```
server:
  port: 8080 #设置 Tomcat 内嵌端口号
  servlet:
    context-path: / #设置上下文根
#配置数据源
spring:
  datasource:
    driver-class-name: com.mysql.cj.jdbc.Driver
    url: jdbc:mysql://127.0.0.1:3306/springboot-01?useUnicode=true&characterEncoding=utf-8&useSSL=false&serverTimezone=GMT
    username: root
    password: root
```

**创建** **RESTfulController，并编写代码**

```
package com.abc.springboot.controller;
​
import org.springframework.web.bind.annotation.*;
​
import java.util.HashMap;
import java.util.Map;
​
@RestController
public class RESTfulController {
​
    /**
     * 添加学生
     * 请求地址：
     * 请求方式：POST
     * @param name
     * @param age
     * @return
     */
    @PostMapping("/student/{name}/{age}")
    public Object addStu(@PathVariable("name") String name,@PathVariable("age") Integer age){
        Map<String,Object> retMap=new HashMap<String, Object>();
        retMap.put("name",name);
        retMap.put("age",age);
​
        return retMap;
    }
    /**
     * 删除学生
     * 请求地址：
     * 请求方式：Delete
     * @param id
     * @return
     */
    @DeleteMapping("/student/{id}")
    public Object removeStu(@PathVariable("id") Integer id){
        return "删除的学生id:"+id;
    }
​
    /**
     * 修改学生信息
     * 请求地址：
     * 请求方式：Put
     * @param id
     * @return
     */
​
    @PutMapping("/student/student/{id}")
    public Object modifyStu(@PathVariable("id") Integer id){
        return "修改的学生id:"+id;
    }
​
    @GetMapping("/student/{id}")
    public Object queryStu(@PathVariable("id") Integer id){
        return "查询学生id:"+id;
    }
}
​
```

**总结：其实这里我们能感受到的好处**

➢ 传递参数变简单了

➢ 服务提供者对外只提供了一个接口服务，而不是传统的 CRUD 四个接口

### **3.4.4** **请求冲突的问题**

➢ 改路径

➢ 改请求方式

**创建** **RESTfulController02类**

```
package com.abc.springboot.controller;
​
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
​
import java.util.HashMap;
import java.util.Map;
​
@RestController
public class RESTfulController02 {
​
    /**
     * id:订单标识
     * status：订单状态
     * 请求路径：
     * @param id
     * @param status
     * @return
     */
    @GetMapping("order/{id}/{status}")
    public Object queryOrder(@PathVariable("id") Integer id,@PathVariable("status") Integer status){
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("id",id);
        map.put("status",status);
        return map;
    }
​
    /**
     * id:订单标识
     * status：订单状态
     * 请求路径：
     * @param id
     * @param status
     * @return
     */
    @GetMapping("order/{id}/{status}")
    public Object queryOrder1(@PathVariable("id") Integer id,@PathVariable("status") Integer status){
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("id",id);
        map.put("status",status);
        return map;
    }
​
    @GetMapping(value = "/springBoot/{status}/order/{id}")
    public Object queryOrder2(@PathVariable("id") Integer id,
                              @PathVariable("status") Integer status) {
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("id",id);
        map.put("status",status);
        return map;
    }
​
    @GetMapping(value = "/springBoot/{status}/order/{id}")
    public Object queryOrder3(@PathVariable("id") Integer id,
                              @PathVariable("status") Integer status) {
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("id",id);
        map.put("status",status);
        return map;
    }
    /**
     * query1 和 query2 两个请求路径会发生请求路径冲突问题
     * query3 与 query1 和 query2 发生请求冲突
     * 注意：虽然两个路径写法改变了，但是由于传递的两个参数都是 int 值，所以不知道该交给
     哪个请求进行处理
     * 就会出现匹配模糊不清的异常，所以要想解决冲突，有两种方式：
     * 1.修改请求路径
     * 2.修改请求方式
     */
}
​
```

### **3.4.5 RESTful** **原则**

➢ 增 post 请求、删 delete 请求、改 put 请求、查 get 请求

➢ **请求路径不要出现动词**

例如：查询订单接口

/boot/order/1021/1（推荐）

/boot/queryOrder/1021/1（不推荐）

➢ **分页、排序等操作，不需要使用斜杠传参数**

例如：订单列表接口

/boot/orders?page=1&sort=desc

一般传的参数不是数据库表的字段，可以不采用斜杠

## **3.5Spring Boot** **集成** **Redis**

### **3.5.1 Spring Boot** **集成** **Redis**

项目名称：05-springboot-redis

**（1） 案例思路**

完善根据学生 id 查询学生的功能，先从 redis 缓存中查找，如果找不到，再从数据库中查找，然后放到 redis 缓存中

**（2） 实现步骤**

**A.** 首先通过 MyBatis **逆向工程生成实体** **bean** **和数据持久层**

**B.在** **pom.xml** **文件中添加** **redis** **依赖**

```
<!-- 加载 spring boot redis 包 -->
<dependency>
 <groupId>org.springframework.boot</groupId>
 <artifactId>spring-boot-starter-data-redis</artifactId>
</dependency>
```

**C.Spring Boot** **核心配置文件**

完整application.properties配置文件如下：

```
#配置内嵌Tomcat端口号
server.port=9090
​
#配置项目上下文根
server.servlet.context-path=/016-springboot-redis
​
#配置连接MySQL数据库信息
spring.datasource.url=jdbc:mysql://192.168.92.134:3306/springboot?useUnicode=true&characterEncoding=UTF-8&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC
spring.datasource.driver-class-name=com.mysql.cj.jdbc.Driver
spring.datasource.username=root
spring.datasource.password=123456
​
​
#配置视图解析器
spring.mvc.view.prefix=/
spring.mvc.view.suffix=.jsp
​
​
#配置redis连接信息(单机模式)
spring.redis.host=192.168.92.134
spring.redis.port=6379
spring.redis.password=123456
```

RedisController类

```
RestController
public class RedisController {
​
    @Autowired
    private StudentService studentService;
​
​
    /**
     * 请求地址：http://localhost:9090/016-springboot-redis//springboot/allStudentCount
     * @param request
     * @return
     */
    @GetMapping(value = "/springboot/allStudentCount")
    public Object allStudentCount(HttpServletRequest request) {
​
        Long allStudentCount = studentService.queryAllStudentCount();
​
        return "学生总人数：" + allStudentCount;
    }
}
```

StudentService接口

```
public interface StudentService {
​
    /**
     * 获取学生总人数
     * @return
     */
    Long queryAllStudentCount();
}
```

在StudentServiceImpl中注入RedisTemplate并修改根据id获取学生的方法配置了上面的步骤，Spring Boot将自动配置RedisTemplate，在需要操作redis的类中注入redisTemplate即可。

注意：Spring Boot帮我们注入RedisTemplate类，泛型里面只能写 、或者什么都不写。

```
@Service("studentServiceImpl")
public class StudentServiceImpl implements StudentService {
​
    @Autowired
    private StudentMapper studentMapper;
​
    @Autowired
    private RedisTemplate redisTemplate;
​
    @Override
    public Long queryAllStudentCount() {
​
        //设置redisTemplate对象key的序列化方式
        redisTemplate.setKeySerializer(new StringRedisSerializer());
​
        //从redis缓存中获取总人数
        Long allStudentCount = (Long) redisTemplate.opsForValue().get("allStudentCount");
​
        //判断是否为空
        if (null == allStudentCount) {
​
            //去数据库查询，并存放到redis缓存中
            allStudentCount = studentMapper.selectAllStudentCount();
​
            redisTemplate.opsForValue().set("allStudentCount",allStudentCount,15, TimeUnit.SECONDS);
​
        }
​
​
        return allStudentCount;
    }
}
```

启动类Application在SpringBoot启动类上添加扫描数据持久层的注解并指定扫描包

```
@SpringBootApplication
@MapperScan(basePackages = "com.bjpowernode.springboot.mapper")//扫描数据持久层
public class Application {
​
    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }
​
}
```

启动SpringBoot应用，访问测试

打开Redis Desktop Mananger查看Redis中的情况

