title: 我在 GitHub 上的开源项目
date: '2021-07-05 16:10:27'
updated: '2021-07-05 16:19:49'
tags: [开源, GitHub]
permalink: /github
---
![GitHub Repo](http://null:-1/images/github_repo.jpg)

### 1. [bolo-blog](https://github.com/Simplecxp/bolo-blog) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[⭐️`0`](https://github.com/Simplecxp/bolo-blog/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/Simplecxp/bolo-blog/network/members "分叉数")&nbsp;&nbsp;[🏠`http://null:-1`](http://null:-1 "项目主页")</span>

✍️ False - code is my life !



---

### 2. [H-watermelon](https://github.com/Simplecxp/H-watermelon) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[⭐️`0`](https://github.com/Simplecxp/H-watermelon/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/Simplecxp/H-watermelon/network/members "分叉数")&nbsp;&nbsp;[🏠`h-watermelon-git-master.simplecxp.vercel.app`](h-watermelon-git-master.simplecxp.vercel.app "项目主页")</span>





---

### 3. [JD-SHELL](https://github.com/Simplecxp/JD-SHELL) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[⭐️`0`](https://github.com/Simplecxp/JD-SHELL/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/Simplecxp/JD-SHELL/network/members "分叉数")</span>

基于github actions的京东自动化签到 撸京豆



---

### 4. [music](https://github.com/Simplecxp/music) <kbd title="主要编程语言">HTML</kbd> <span style="font-size: 12px;">[⭐️`0`](https://github.com/Simplecxp/music/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/Simplecxp/music/network/members "分叉数")&nbsp;&nbsp;[🏠`music.simplecxp.vercel.app`](music.simplecxp.vercel.app "项目主页")</span>





---

### 5. [playground-macos-main](https://github.com/Simplecxp/playground-macos-main) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[⭐️`0`](https://github.com/Simplecxp/playground-macos-main/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/Simplecxp/playground-macos-main/network/members "分叉数")</span>





---

### 6. [Simplecxp](https://github.com/Simplecxp/Simplecxp) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[⭐️`0`](https://github.com/Simplecxp/Simplecxp/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/Simplecxp/Simplecxp/network/members "分叉数")&nbsp;&nbsp;[🏠`https://github.com/Simplecxp`](https://github.com/Simplecxp "项目主页")</span>

Config files for my GitHub profile.



---

### 7. [SpringBootA](https://github.com/Simplecxp/SpringBootA) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[⭐️`0`](https://github.com/Simplecxp/SpringBootA/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/Simplecxp/SpringBootA/network/members "分叉数")</span>

两表增删改查



---

### 8. [Teacher](https://github.com/Simplecxp/Teacher) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[⭐️`0`](https://github.com/Simplecxp/Teacher/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/Simplecxp/Teacher/network/members "分叉数")</span>

增删改查

