title: SpringBoot工程热部署
date: '2021-06-04 21:13:00'
updated: '2021-08-19 20:35:06'
tags: [SpringBoot]
permalink: /articles/2021/06/21/1624282701951.html
---
我们在开发中反复修改类、页面等资源，每次修改后都是需要重新启动才生效，这样每次启动都很麻

烦，浪费了大量的时间，我们可以在修改代码后不重启就能生效，在 pom.xml 中添加如下配置就可以

实现这样的功能，我们称之为热部署。

```
<!--热部署配置-->
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-devtools</artifactId>
        </dependency>
```

注意：IDEA进行SpringBoot热部署失败原因

出现这种情况，并不是热部署配置问题，其根本原因是因为Intellij IEDA默认情况下不会自动编译，需要

对IDEA进行自动编译的设置，如下：

打开设置--》找到Build ----》Compiler ----》勾选Build project automatically

ctrl+shift+alt+/

选择Regitry

勾选**compiler.automa ke.allow.when.app.running**

