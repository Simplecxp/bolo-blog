title: 文章信息---articleinfo
date: '2021-07-18 00:10:00'
updated: '2021-08-19 20:32:44'
tags: [vue, BladeX]
permalink: /articles/2021/07/18/1627662793792.html
---
api

```
import request from '@/router/axios';

export const getList = (current, size, params) => {
  return request({
    url: '/api/article_info/articleinfo/page',
    method: 'get',
    params: {
      ...params,
      current,
      size,
    }
  })
}

export const getDetail = (id) => {
  return request({
    url: '/api/article_info/articleinfo/detail',
    method: 'get',
    params: {
      id
    }
  })
}

export const remove = (ids) => {
  return request({
    url: '/api/article_info/articleinfo/remove',
    method: 'post',
    params: {
      ids,
    }
  })
}

export const add = (row) => {
  return request({
    url: '/api/article_info/articleinfo/submit',
    method: 'post',
    data: row
  })
}

export const update = (row) => {
  return request({
    url: '/api/article_info/articleinfo/submit',
    method: 'post',
    data: row
  })
}

export const getDeptTree = () => {
  return request({
    url: '/api/cascade_classification/cascadeclassification/tree',
    method: 'get'
  })
}

export const imgadd = (row) => {
  return request({
    url: '/api/attachment_info/attachmentinfo/save',
    method: 'post',
    data: row
  })
}
/* export const imglist = (row) => {
  return request({
    url: '/api/attachment_info/attachmentinfo/imglist',
    method: 'get',
    data: row
  })
} */

export const addstatic = (row) => {
  return request({
    url: '/api/article_state/articlestate/save',
    method: 'post',
    data: row
  })
}
```

articleinfo.vue

```
<template>
  <basic-container>
    <avue-crud :option="option"
               :table-loading="loading"
               :data="data"
               :page.sync="page"
               :permission="permissionList"
               :before-open="beforeOpen"
               v-model="form"
               ref="crud"
               @row-update="rowUpdate"
               @row-save="rowSave"
               @row-del="rowDel"
               @search-change="searchChange"
               @search-reset="searchReset"
               @selection-change="selectionChange"
               @current-change="currentChange"
               @size-change="sizeChange"
               @refresh-change="refreshChange"
               @on-load="onLoad"
                :upload-after="uploadAfter"
                @change="changeSwitch(scope.row)"
                >
      <template slot="menuLeft">
        <el-button type="danger"
                   size="small"
                   icon="el-icon-delete"
                   plain
                   v-if="permission.articleinfo_delete"
                   @click="handleDelete">删 除
        </el-button>

      </template>
    </avue-crud>
  </basic-container>
</template>

<script>
  import {getList, getDetail, add, update, remove,getDeptTree,imgadd,addstatic} from "@/api/article_info/articleinfo";
  /* import {getpathDetail} from "@/api/attachment_info/attachmentinfo"; */
  import {getStartDetail,updateStatus} from "@/api/article_state/articlestate";
  import {mapGetters} from "vuex";



  export default {
    data() {
      return {
        stateid:null,
        form: {},
        artsId:{
          navShowState:null,
          originalState:null,
          recommendState:null,
          attentionShowState:null,
        },
        query: {},
        loading: true,
        page: {
          pageSize: 10,
          currentPage: 1,
          total: 0
        },
        selectionList: [],
        option: {
          //labelWidth:"150px",
          height:'auto',
          calcHeight: 30,
          tip: false,
          searchShow: true,
          searchMenuSpan: 6,
          border: true,
          index: true,
          viewBtn: true,
          selection: true,
          dialogClickModal: false,
          dialogHeight: 700,
          column: [

            {
              label: "标题",
              prop: "articleName",
              rules: [{
                required: true,
                message: "请输入标题",
                trigger: "blur"
              }]
            },
            {
              label: "副标题",
              prop: "articleSecondName",
              rules: [{
                required: true,
                message: "请输入副标题",
                trigger: "blur"
              }]
            },
            {
              label: "作者",
              prop: "author",
              rules: [{
                required: true,
                message: "请输入作者",
                trigger: "blur"
              }]
            },
            {
              label: "来源",
              prop: "articleSource",
              rules: [{
                required: true,
                message: "请输入来源",
                trigger: "blur"
              }]
            },


            {
              label: "内容",
              prop: "articleContent",
              component: 'AvueUeditor',
              options: {
                action: '/api/attachment_info/attachmentinfo/img',
                props: {
                  res: "data",
                  url: "url",
                }
              },
              hide: true,
              minRows: 6,
              span: 24,
            },

            {
              label: "分类级联",
              prop: "cascadeId",
              dicData: [],
              type: "tree",
              hide: true,
              addDisabled: false,
              props: {
                label: "title"
              },
              rules: [{
                required: true,
                message: "请输入分类级联标识,对应分类级联表主键标识",
                trigger: "click"
              }]
            },


            {
              label: '文章封面',
              prop:'articlePath',
              type: 'upload',
              listType: 'picture-img',
              row:true,
              span: 24,
              rules: [{
                required: true,
                message: "请输入文章封面附件引用",
                trigger: "blur"
              }],
              propsHttp: {
                res:'data',
                url:'attachmentPath',
              },

              tip: '只能上传jpg/png用户头像，且不超过500kb',
              action: '/api/attachment_info/attachmentinfo/img',//使用隔壁家附件分类图片上传
              hide:false,
            },
             /* {
              label: '文章附件',
              prop: 'attachmentId',
              type: 'tree',
              dicData: [],
              filterText:'搜索关键字制自定义',
              multiple:true,
              props: {
                label: "title"
              }
            }, */

           {
              label: "文章附件",
              prop: "attachmentId",
              type: "tree",
              multiple:true,
              dicUrl: "/api/attachment_info/attachmentinfo/selectAllImg?typeId=0",
              props: {
                label: "attachmentName",
                value: "id"
              },
              rules: [{
                required: true,
                message: "请输入文章附件引用,	            对应附件标识，1-5个，JSON格式，例如：[id1, id2, id3]。",
                trigger: "blur"
              }]
            },
            /* {
              label: "状态标识",
              prop: "artsId",
              rules: [{
                required: true,
                message: "请输入页面显示状态标识",
                trigger: "blur"
              }]
            }, */

          ],
          group: [
            {
              label: '文章状态',
              prop: 'artsId',
              icon: 'el-icon-edit-outline',
              column: [
                {
                    label: "首页显示状态",
                    prop: "navShowState",
                    span: 12,
                    type: "switch",
                    dicData:[{
                      label:'不展示',
                      value:0
                    },{
                      label:'展示',
                      value:1
                    }],
                    mock:{
                      type:'dic'
                    },
                    hide: true,

                },
                {
                    label: "是否为原创",
                    prop: "originalState",
                    span: 8,
                    type: "switch",
                    dicData: [{
                      label:'非原创',
                      value:0
                    },{
                      label:'原创',
                      value:1
                    }],
                    mock:{
                      type:'dic'
                    },
                    hide: true,
                    row:true,
                },
                {
                    label: "推荐状态",
                    prop: "recommendState",
                    span: 12,
                    type: "switch",
                    dicData: [{
                      label:'不推荐',
                      value:0
                    },{
                      label:'推荐',
                      value:1
                    }],
                    mock:{
                      type:'dic'
                    },
                    hide: true,
                    row:false,
                },
                {
                    label: "关注页面显示状态",
                    prop: "attentionShowState",
                    span: 8,
                    type: "switch",
                    dicData: [{
                      label:'不显示',
                      value:0
                    },{
                      label:'显示',
                      value:1
                    }],
                    mock:{
                      type:'dic'
                    },
                    hide: true,
                    row:false,
                },
              ],
             },
            ]

        },
        data: [],
        artice_info:{//给上传图片赋值
          attachmentType:0,
          attachmentName:'',
          attachmentSuffix:'',
          attachmentSize:'',
          attachmentPath:'',
        },
        articleTop_Id: '',

      };
    },
    computed: {
      ...mapGetters(["permission"]),
      permissionList() {
        return {
          addBtn: this.vaildData(this.permission.articleinfo_add, false),
          viewBtn: this.vaildData(this.permission.articleinfo_view, false),
          delBtn: this.vaildData(this.permission.articleinfo_delete, false),
          editBtn: this.vaildData(this.permission.articleinfo_edit, false)
        };
      },
      ids() {
        let ids = [];
        this.selectionList.forEach(ele => {
          ids.push(ele.id);
        });
        return ids.join(",");
      }
    },
    methods: {
      initData() {
        getDeptTree().then(res => {
          const column = this.findObject(this.option.column, "cascadeId");
          column.dicData = res.data.data;
          console.info(res.data.data)
        });
      },
      uploadAfter(res, done, loading,column) {
        console.log(res,column.prop)
        this.img = res;
        console.info('上传的图片属性',this.img)
        this.img.attachmentType = this.artice_info.attachmentType
        this.artice_info.attachmentSuffix = this.img.attachmentSuffix
        this.artice_info.attachmentSize = this.img.attachmentSize
        this.artice_info.attachmentName = this.img.attachmentName
        this.artice_info.attachmentPath = this.img.attachmentPath

        console.info('path',this.img.attachmentType,this.artice_info.attachmentPath,this.artice_info.attachmentSize,this.artice_info.attachmentName)

        imgadd(this.artice_info).then((res) => {
          this.articleTop_Id=res.data.data;
          this.$message({
            type: "success",
            message: "图片添加成功!"
          });
          done();
        }, error => {
          loading();
          window.console.log(error);
        });
        this.$message.success('上传后的方法')
      },
      rowSave(row, done, loading) {
        this.artsId.id=row.artsId
        this.artsId.navShowState = row.navShowState;
        this.artsId.originalState = row.originalState;
        this.artsId.recommendState = row.recommendState;
        this.artsId.attentionShowState = row.attentionShowState;
        console.info("状态==",this.artsId)

        addstatic(this.artsId).then(res => {//状态
          this.$message({
            type: "success",
            message: "ture状态添加成功!"
          });
          done();
          this.stateid=res.data.data;
          console.info("this.stateid",this.stateid)
          row.artsId = this.stateid;
          console.info("状态artsId==",row.artsId)

          console.info("打印转换之前",row.attachmentId)
          row.attachmentId = JSON.stringify(row.attachmentId);
          console.info("打印转换之后",row.attachmentId)
          row.articleTopId = this.articleTop_Id;
          console.info("articleTopId",row.articleTopId)

          add(row).then(() => {
            this.onLoad(this.page);
            this.$message({
              type: "success",
              message: "操作成功!"
            });
            done();
          }, error => {
            loading();
            window.console.log(error);
          })
        })
      },
      rowUpdate(row, index, done, loading) {
        console.info("修改之前row",row)
        //修改状态
        this.artsId.id=row.artsId
        this.artsId.navShowState = row.navShowState;
        this.artsId.originalState = row.originalState;
        this.artsId.recommendState = row.recommendState;
        this.artsId.attentionShowState = row.attentionShowState;
        console.info(this.artsId)

        updateStatus(this.artsId).then(() => {
          this.onLoad(this.page);
          this.$message({
            type: "success",
            message: "ture状态修改成功!"
          });
          done();
          /* row.artsId = this.form.artsId;
          console.info("状态artsId==",row.artsId) */
          console.info('状态修改之后',row)

          })
          console.info("打印转换之前",this.form.attachmentId)
          row.attachmentId = JSON.stringify(this.form.attachmentId);
          console.info("打印转换之后",this.form.attachmentId)

          row.articleTopId = this.articleTop_Id;
          console.info("articleTopId",this.articleTop_Id)
          update(row).then(() => {
            this.onLoad(this.page);
            this.$message({
              type: "success",
              message: "操作成功!"
            });
            done();
            console.info("修改之后row=>",row)
          }, error => {
            loading();
            console.log(error);
          });

      },
      rowDel(row) {
        this.$confirm("确定将选择数据删除?", {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning"
        })
          .then(() => {
            return remove(row.id);
          })
          .then(() => {
            this.onLoad(this.page);
            this.$message({
              type: "success",
              message: "操作成功!"
            });
          });
      },
      handleDelete() {
        if (this.selectionList.length === 0) {
          this.$message.warning("请选择至少一条数据");
          return;
        }
        this.$confirm("确定将选择数据删除?", {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning"
        })
          .then(() => {
            return remove(this.ids);
          })
          .then(() => {
            this.onLoad(this.page);
            this.$message({
              type: "success",
              message: "操作成功!"
            });
            this.$refs.crud.toggleSelection();
          });
      },
      beforeOpen(done, type) {
        if (["add", "edit"].includes(type)) {
          this.initData();
        }
        if (["edit", "view"].includes(type)) {
          //获取状态回显
          getStartDetail(this.form.artsId).then(res =>{
             this.form.navShowState = res.data.data.navShowState;
             this.form.originalState = res.data.data.originalState;
             this.form.recommendState = res.data.data.recommendState;
             this.form.attentionShowState =res.data.data.attentionShowState;
             console.info('状态回显', this.form)
           })
          getDetail(this.form.id).then(res => {
             console.info("点击的查看修改idddd",res)
            this.form = res.data.data;
            res.data.data.attachmentId = JSON.parse(this.form.attachmentId);
            console.info(res.data.data.attachmentId)
          });
        }
        done();
      },
      searchReset() {
        this.query = {};
        this.onLoad(this.page);
      },
      searchChange(params, done) {
        this.query = params;
        this.page.currentPage = 1;
        this.onLoad(this.page, params);
        done();
      },
      selectionChange(list) {
        this.selectionList = list;
      },
      selectionClear() {
        this.selectionList = [];
        this.$refs.crud.toggleSelection();
      },
      currentChange(currentPage){
        this.page.currentPage = currentPage;
      },
      sizeChange(pageSize){
        this.page.pageSize = pageSize;
      },
      refreshChange() {
        this.onLoad(this.page, this.query);
      },
      onLoad(page, params = {}) {
        this.loading = true;
        getList(page.currentPage, page.pageSize, Object.assign(params, this.query)).then(res => {
          const data = res.data.data;
          this.page.total = data.total;
          this.data = data.records;
          console.info(data.records)
          this.loading = false;
          this.selectionClear();
          /* getpathDetail().then(()=>{
          }) */
        });
      },


    }
  };
</script>

<style>
</style>
```

![articleinfo](https://b3logfile.com/file/2021/07/image-6fdf333c.png)

