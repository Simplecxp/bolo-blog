title: 附件分类---attachmentinfo
date: '2021-07-17 00:10:00'
updated: '2021-07-17 00:10:00'
tags: [vue, BladeX]
permalink: /articles/2021/07/17/1627662485936.html
---
api

```
import request from '@/router/axios';

export const getList = (current, size, params) => {
  return request({
    url: '/api/attachment_info/attachmentinfo/list',
    method: 'get',
    params: {
      ...params,
      current,
      size,
    }
  })
}

export const getDetail = (id) => {
  return request({
    url: '/api/attachment_info/attachmentinfo/detail',
    method: 'get',
    params: {
      id
    }
  })
}

export const getpathDetail = (id) => {
  return request({
    url: '/api/attachment_info/attachmentinfo/detail',
    method: 'get',
    params: {
      id
    }
  })
}

export const remove = (ids) => {
  return request({
    url: '/api/attachment_info/attachmentinfo/remove',
    method: 'post',
    params: {
      ids,
    }
  })
}

export const add = (row) => {
  return request({
    url: '/api/attachment_info/attachmentinfo/submit',
    method: 'post',
    data: row
  })
}

export const update = (row) => {
  return request({
    url: '/api/attachment_info/attachmentinfo/submit',
    method: 'post',
    data: row
  })
}
```

attachmentinfo.vue

```
<template>
  <basic-container>
    <avue-crud
      :option="option"

               :table-loading="loading"
               :data="data"
               :page.sync="page"
               :permission="permissionList"
               :before-open="beforeOpen"
               v-model="form"

               ref="crud"
               @row-update="rowUpdate"
               @row-save="rowSave"
               @row-del="rowDel"
               @search-change="searchChange"
               @search-reset="searchReset"
               @selection-change="selectionChange"
               @current-change="currentChange"
               @size-change="sizeChange"
               @refresh-change="refreshChange"
               @on-load="onLoad"
                @reset-change="emptytChange"

                :upload-preview="uploadPreview" :upload-error="uploadError" :upload-exceed="uploadExceed" :upload-delete="uploadDelete" :upload-before="uploadBefore" :upload-after="uploadAfter">
      <template slot="menuLeft">
        <el-button type="danger"
                   size="small"
                   icon="el-icon-delete"
                   plain
                   v-if="permission.attachmentinfo_delete"
                   @click="handleDelete">删 除
        </el-button>
      </template>
    </avue-crud>
  </basic-container>

</template>


<script>


  import {getList, getDetail, add, update, remove} from "@/api/attachment_info/attachmentinfo";
  import {mapGetters} from "vuex";

  var DIC = {
      VAILD: [{
          label: '文章附件',
          value: 0
      }, {
          label: '广告附件',
          value: 1
      },{
          label: '关注附件',
          value: 2
      },{
          label: '活动附件',
          value: 3
      }],

      }

  export default {
    data() {
      return {

        form: {},
        query: {},
        loading: true,
        page: {
          pageSize: 10,
          currentPage: 1,
          total: 0
        },
        selectionList: [],

        option: {
          height:'auto',
          calcHeight: 30,
          tip: false,
          searchShow: true,
          searchMenuSpan: 6,
          border: true,
          index: true,
          viewBtn: true,
          selection: true,
          dialogClickModal: false,
          column: [
            {
              label: "附件分类",
              prop: "attachmentType",
              type: "select",
              dicData: DIC.VAILD,
              mock:{
                    type:'dic',
                  },
              rules: [{
                required: true,
                message: "请输入附件分类,	            0.文章附件	            1.广告附件	            2.关注附件	            3.活动附件",
                trigger: "blur"
              }]
            },
            {
              label: '附件',
              prop:'attachmentPath',
              type: 'upload',
              listType: 'picture-img',
              span: 24,
              rules: [{
                required: true,
                message: "请输入附件名称,	            即源文件名称（含后缀名）",
                trigger: "blur"
              }],
              propsHttp: {
                res:'data'
              },
              tip: '只能上传jpg/png用户头像，且不超过500kb',
              action: '/api/attachment_info/attachmentinfo/img'
            },


            {
              label: '附件名称',
              prop: 'attachmentName',
              rules: [{
                required: true,
                message: "请输入附件名称,	            即源文件名称（含后缀名）",
                trigger: "blur"
              }],
            },

            {
              label: "附件后缀",
              prop: "attachmentSuffix",
              rules: [{
                required: true,
                message: "请输入附件后缀,	            文件后缀名（例如jpg/png）",
                trigger: "blur"
              }]
            },
            {
              label: "附件大小",
              prop: "attachmentSize",
              rules: [{
                required: true,
                message: "请输入附件大小,	            单位字节。",
                trigger: "blur"
              }]
            },
            {
              label: "附件地址",
              prop: "attachmentPath",
              rules: [{
                required: true,
                message: "请输入附件地址,	            相对地址，系统上传后生成，格式：upload/yyyyMMdd/uuid.xxx。",
                trigger: "blur"
              }]
            },
          ]
        },
        data: [],
        artice_info:{
          attachmentName:'',
          attachmentSuffix:'',
          attachmentSize:'',
          attachmentPath:'',
        },

      };
    },
    computed: {
      ...mapGetters(["permission"]),
      permissionList() {
        return {
          addBtn: this.vaildData(this.permission.attachmentinfo_add, false),
          viewBtn: this.vaildData(this.permission.attachmentinfo_view, false),
          delBtn: this.vaildData(this.permission.attachmentinfo_delete, false),
          editBtn: this.vaildData(this.permission.attachmentinfo_edit, false)
        };
      },
      ids() {
        let ids = [];
        this.selectionList.forEach(ele => {
          ids.push(ele.id);
        });
        return ids.join(",");
      }
    },
    methods: {
      rowSave(row, done, loading) {
        add(row).then(() => {
          this.onLoad(this.page);
          this.$message({
            type: "success",
            message: "操作成功!"
          });
          done();
        }, error => {
          loading();
          window.console.log(error);
        });
      },
      rowUpdate(row, index, done, loading) {
        update(row).then(() => {
          this.onLoad(this.page);
          this.$message({
            type: "success",
            message: "操作成功!"
          });
          done();
        }, error => {
          loading();
          console.log(error);
        });
      },
      rowDel(row) {
        this.$confirm("确定将选择数据删除?", {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning"
        })
          .then(() => {
            return remove(row.id);
          })
          .then(() => {
            this.onLoad(this.page);
            this.$message({
              type: "success",
              message: "操作成功!"
            });
          });
      },
      handleDelete() {
        if (this.selectionList.length === 0) {
          this.$message.warning("请选择至少一条数据");
          return;
        }
        this.$confirm("确定将选择数据删除?", {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning"
        })
          .then(() => {
            return remove(this.ids);
          })
          .then(() => {
            this.onLoad(this.page);
            this.$message({
              type: "success",
              message: "操作成功!"
            });
            this.$refs.crud.toggleSelection();
          });
      },
      beforeOpen(done, type) {
        if (["edit", "view"].includes(type)) {
          getDetail(this.form.id).then(res => {
            this.form = res.data.data;
          });
        }
        done();
      },
      searchReset() {
        this.query = {};
        this.onLoad(this.page);
      },
      searchChange(params, done) {
        this.query = params;
        this.page.currentPage = 1;
        this.onLoad(this.page, params);
        done();
      },
      selectionChange(list) {
        this.selectionList = list;
      },
      selectionClear() {
        this.selectionList = [];
        this.$refs.crud.toggleSelection();
      },
      currentChange(currentPage){
        this.page.currentPage = currentPage;
      },
      sizeChange(pageSize){
        this.page.pageSize = pageSize;
      },
      refreshChange() {
        this.onLoad(this.page, this.query);
      },
      onLoad(page, params = {}) {
        this.loading = true;
        getList(page.currentPage, page.pageSize, Object.assign(params, this.query)).then(res => {
          const data = res.data.data;
          this.page.total = data.total;
          this.data = data.records;
          this.loading = false;
          this.selectionClear();
        });
      },
      uploadDelete(column,file) {
            console.log(column,file)
            return new Promise((resolve, reject) => {
                this.$confirm('此操作将永久删除该文件, 是否继续?', '提示', {
                  confirmButtonText: '确定',
                  cancelButtonText: '取消',
                  type: 'warning'
                }).then(() => {
                  this.form.attachmentName=''
                  this.form.attachmentSize=''
                  this.form.attachmentSuffix=''
                  //this.form.attachmentType=''
                  //return this.$confirm(`是否确定移除该选项？`);
                  // 操作完以后  resolve出去，因为这样avue会将原来的数据给清除  如果不resolve，那么再添加图片的话  他会把得到的路径与之前的拼接成一个字符串用“，”分割
                  resolve()
                }).catch(() => {
              
                  reject()
                  this.$message({
                    type: 'info',
                    message: '已取消删除'
                  })
                })
            })
          },
          uploadBefore(file, done, loading,column) {
            console.log(file,column)
            //如果你想修改file文件,由于上传的file是只读文件，必须复制新的file才可以修改名字，完后赋值到done函数里,如果不修改的话直接写done()即可
            //var newFile = new File([file], '1234', { type: file.type });
            done()
            this.$message.success('上传前的方法')
          },

          uploadError(error, column) {
            this.$message.success('上传失败')
            console.log(error, column)
          },
          uploadAfter(res, done, loading,column) {
            console.log(res,column.prop)
            this.img=res
            console.info('上传的图片属性',this.img)
            this.artice_info.attachmentSuffix = this.img.attachmentSuffix
            this.artice_info.attachmentSize = this.img.attachmentSize
            this.artice_info.attachmentName = this.img.attachmentName
            this.artice_info.attachmentPath = this.img.attachmentPath
            this.form=this.artice_info //进行数据回显
            done()
            this.$message.success('上传后的方法')
          }
    }
  };
</script>

<style>
</style>
```

![attachmentinfo](https://b3logfile.com/file/2021/07/image-4785b626.png)



