title: vue图片上传
date: '2021-06-04 10:44:00'
updated: '2021-06-04 10:44:00'
tags: [vue]
permalink: /articles/2021/06/04/1622774691699.html
---
后台代码

```
/**
 * 本类用于图片上传
 */
@RestController
@RequestMapping("/img")
public class uploadController {


    @RequestMapping("/upload")
    public String imgUpload(MultipartFile file) throws IOException {
        /**
         * MultipartFile
         * 是spring类型，代表form中 的data方式上传
         * 包含二进制文件名称，和数据
         */
        //定义存储图片的地址
        String folder ="D:/vue-workspace/train/static/img";
        //创建文件夹
        File imgFolder = new File(folder);
        //获取上传的文件名称
        String fname = file.getOriginalFilename();
        //获取上传的文件名的后缀
        String ext = "."+fname.substring(fname.lastIndexOf(".")+1);
        //获取当前上传文件的上传时间 的时间字符串
        String dateTimeFormatter = DateTimeFormatter.ofPattern("yyyyMMddHHmmss").format(LocalDateTime.now());
        //生成由上传时间和UUID组成的新的文件名
        String newFileName = dateTimeFormatter + UUID.randomUUID().toString().replaceAll("-","")+ext;
        //
        File filePath = new File(imgFolder,newFileName);
        /**
         * 为了防止创建文件时其文件所在的文件夹不存在，抛出异常
         */
        if (!filePath.getParentFile().exists()){
            filePath.getParentFile().mkdirs();
        }try {
            file.transferTo(filePath);
            //返回我们所需要的文件名
            return filePath.getName();
        }catch (IOException e){
            e.printStackTrace();
            return "";
        }
    }
}
```

前台代码 Element UI

```
<template>
<div>
  <h1>头像上传</h1>
  <el-upload
    class="avatar-uploader"
    action="/api/img/upload"
    :show-file-list="false"
    :on-success="handleAvatarSuccess"
    :before-upload="beforeAvatarUpload">
    <img v-if="imageUrl" :src="imageUrl" class="avatar">
    <i v-else class="el-icon-plus avatar-uploader-icon"></i>
  </el-upload>
</div>

</template>


<style>
  .avatar-uploader .el-upload {
    border: 1px dashed #d9d9d9;
    border-radius: 6px;
    cursor: pointer;
    position: relative;
    overflow: hidden;
  }
  .avatar-uploader .el-upload:hover {
    border-color: #409EFF;
  }
  .avatar-uploader-icon {
    font-size: 28px;
    color: #8c939d;
    width: 178px;
    height: 178px;
    line-height: 178px;
    text-align: center;
  }
  .avatar {
    width: 178px;
    height: 178px;
    display: block;
  }
</style>

<script>
  export default {
    data() {
      return {
        imageUrl: ''
      };
    },
    methods: {
      handleAvatarSuccess(res, file) {
        this.imageUrl = URL.createObjectURL(file.raw);
      },
      beforeAvatarUpload(file) {
        const isJPG = file.type === 'image/jpeg';
        const isLt2M = file.size / 1024 / 1024 < 2;

        if (!isJPG) {
          this.$message.error('上传头像图片只能是 JPG 格式!');
        }
        if (!isLt2M) {
          this.$message.error('上传头像图片大小不能超过 2MB!');
        }
        return isJPG && isLt2M;
      }
    }
  }
</script>

```

