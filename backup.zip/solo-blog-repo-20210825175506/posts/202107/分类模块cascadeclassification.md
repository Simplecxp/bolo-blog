title: 分类模块---cascadeclassification
date: '2021-07-16 00:10:00'
updated: '2021-08-19 20:32:57'
tags: [vue, BladeX]
permalink: /articles/2021/07/16/1627661985686.html
---
api

```
import request from '@/router/axios';

export const getList = (current, size, params) => {
  return request({
    url: '/api/cascade_classification/cascadeclassification/list',
    method: 'get',
    params: {
      ...params,
      current,
      size,
    }
  })
}

export const getDetail = (id) => {
  return request({
    url: '/api/cascade_classification/cascadeclassification/detail',
    method: 'get',
    params: {
      id
    }
  })
}

export const remove = (ids) => {
  return request({
    url: '/api/cascade_classification/cascadeclassification/remove',
    method: 'post',
    params: {
      ids,
    }
  })
}

export const add = (row) => {
  return request({
    url: '/api/cascade_classification/cascadeclassification/submit',
    method: 'post',
    data: row
  })
}

export const update = (row) => {
  return request({
    url: '/api/cascade_classification/cascadeclassification/submit',
    method: 'post',
    data: row
  })
}


export const getDeptTree = () => {
  return request({
    url: '/api/cascade_classification/cascadeclassification/tree',
    method: 'get'
  })
}
```

```
<script>
  import {getList, getDetail, add, update, remove,getDeptTree} from "@/api/cascade_classification/cascadeclassification";
  import {mapGetters} from "vuex";

  var DIC = {
      VAILD: [{
          label: '一级标题',
          value: 1
      }, {
          label: '二级标题',
          value: 2
      },{
          label: '三级标题',
          value: 3
      }],

      }

  export default {
    data() {
      return {
        form: {},
        query: {},
        loading: true,
        page: {
          pageSize: 10,
          currentPage: 1,
          total: 0
        },
        selectionList: [],
        option: {
          height:'auto',
          calcHeight: 30,
          tip: false,
          searchShow: true,
          searchMenuSpan: 6,
          border: true,
          index: true,
          viewBtn: true,
          selection: true,
          dialogClickModal: false,
          column: [

            {
              label: "分类模块名",
              prop: "cascadeName",
              rules: [{
                required: true,
                message: "请输入分类模块名",
                trigger: "blur"
              }]
            },
            {
              label: "等级标识  ",
              type: "select",
              dicData: DIC.VAILD,
              prop: "gradeFlag",
              mock:{
                    type:'dic',
                  },
              rules: [{
                required: true,
                message: "请输入等级标识,	            0.	            1.一级标题(主体模块)	            2.二级标题(一级下的子标题)	            3.三级标题(二级下的子标题)	            ",
                trigger: "blur"
              }]
            },

            {
              label: "父级引用标识",
              prop: "parentId",
              dicData: [],
              type: "tree",
              hide: true,
              addDisabled: false,
              props: {
                label: "title"
              },
              rules: [{
                required: false,
                message: "请输入父级引用标识,	引用主键标识",
                trigger: "click"
              }]
            },

            {
              label: "是否为更多",
              prop: "isMore",
              type: "radio",
              dicData: [
                {
                  label: "是",
                  value: 1
                },
                {
                  label: "否",
                  value: 2
                }
              ]
            },

            {
              label: "外部链接	",
              prop: "externalLinks",
              prepend:'http://',
              rules: [{
                required: true,
                message: "请输入外部链接	作为URL地址",
                trigger: "blur"
              }]
            },
            {
              label: "排列顺序",
              prop: "sortOrder",
              type: "number",
              align: "right",
              width: 80,
              rules: [{
                required: true,
                message: "请输入排序",
                trigger: "blur"
              }]
            },

          ]
        },
        data: []
      };
    },
    computed: {
      ...mapGetters(["permission"]),
      permissionList() {
        return {
          addBtn: this.vaildData(this.permission.cascadeclassification_add, false),
          viewBtn: this.vaildData(this.permission.cascadeclassification_view, false),
          delBtn: this.vaildData(this.permission.cascadeclassification_delete, false),
          editBtn: this.vaildData(this.permission.cascadeclassification_edit, false)
        };
      },
      ids() {
        let ids = [];
        this.selectionList.forEach(ele => {
          ids.push(ele.id);
        });
        return ids.join(",");
      }
    },
    methods: {
      initData() {
        getDeptTree().then(res => {
          const column = this.findObject(this.option.column, "parentId");
          column.dicData = res.data.data;
          console.info(res.data.data)
        });
      },
      rowSave(row, done, loading) {
        add(row).then(() => {
          this.onLoad(this.page);
          this.$message({
            type: "success",
            message: "操作成功!"
          });
          done();
        }, error => {
          loading();
          window.console.log(error);
        });
      },
      rowUpdate(row, index, done, loading) {
        update(row).then(() => {
          this.onLoad(this.page);
          this.$message({
            type: "success",
            message: "操作成功!"
          });
          done();
        }, error => {
          loading();
          console.log(error);
        });
      },
      rowDel(row) {
        this.$confirm("确定将选择数据删除?", {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning"
        })
          .then(() => {
            return remove(row.id);
          })
          .then(() => {
            this.onLoad(this.page);
            this.$message({
              type: "success",
              message: "操作成功!"
            });
          });
      },
      handleDelete() {
        if (this.selectionList.length === 0) {
          this.$message.warning("请选择至少一条数据");
          return;
        }
        this.$confirm("确定将选择数据删除?", {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning"
        })
          .then(() => {
            return remove(this.ids);
          })
          .then(() => {
            this.onLoad(this.page);
            this.$message({
              type: "success",
              message: "操作成功!"
            });
            this.$refs.crud.toggleSelection();
          });
      },
      beforeOpen(done, type) {
        if (["add", "edit"].includes(type)) {
          this.initData();
        }
        if (["edit", "view"].includes(type)) {
          getDetail(this.form.id).then(res => {
            this.form = res.data.data;
          });
        }
        done();
      },
      searchReset() {
        this.query = {};
        this.onLoad(this.page);
      },
      searchChange(params, done) {
        this.query = params;
        this.page.currentPage = 1;
        this.onLoad(this.page, params);
        done();
      },
      selectionChange(list) {
        this.selectionList = list;
      },
      selectionClear() {
        this.selectionList = [];
        this.$refs.crud.toggleSelection();
      },
      currentChange(currentPage){
        this.page.currentPage = currentPage;
      },
      sizeChange(pageSize){
        this.page.pageSize = pageSize;
      },
      refreshChange() {
        this.onLoad(this.page, this.query);
      },
      onLoad(page, params = {}) {
        this.loading = true;
        getList(page.currentPage, page.pageSize, Object.assign(params, this.query)).then(res => {
          const data = res.data.data;
          this.page.total = data.total;
          this.data = data.records;
          this.loading = false;
          this.selectionClear();
        });
      }
    }
  };
</script>
```

![cascadeclassification](https://b3logfile.com/file/2021/07/image-e2fb631e.png)

