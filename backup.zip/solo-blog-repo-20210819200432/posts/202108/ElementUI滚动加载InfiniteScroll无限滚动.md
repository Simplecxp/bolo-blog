title: Element-UI 滚动加载 InfiniteScroll 无限滚动
date: '2021-08-18 00:26:14'
updated: '2021-08-19 20:00:19'
tags: [vue]
permalink: /articles/2021/08/18/1629217574925.html
---
![image20210817234656710.png](https://b3logfile.com/file/2021/08/image-20210817234656710-14efa420.png)

**在要实现滚动加载的列表上上添加**`v-infinite-scroll`**，并赋值相应的加载方法，可实现滚动到底部时自动执行加载方法。**

```
<div class="e-left-img"
    v-infinite-scroll="load"
    infinite-scroll-disabled="disabled"
    style="overflow:auto;height: 1361px">
    
    <div class="e-con" v-for="item in list">
        <img :src="item.articlePath" width="50%">
        <div class="e-left-content">
            <span>{{item.articleName}}</span>
            <p v-html="item.articleContent"></p>
        </div>
    </div>
    <p v-if="loading">加载中...</p>
    <p v-if="noMore">没有更多了</p>
</div>
​
<script>
    export default {
    data () {
      return {
        count: 0,//起始页数值为0
        loading: false,
        list: [] //后端返回的数组
      }
    },
    computed: {
        noMore () {
          //当起始页数大于总页数时停止加载
          return this.count >= 10
        },
        disabled () {
          return this.loading || this.noMore
        }
    },
     methods:{
        load() {
          //滑到底部时进行加载
          this.loading = true;
          setTimeout(() => {
            this.count += 1; //页数+1
            this.loading = false
            this.caseid('1415629827754434562');//调用接口，此时页数+1，查询下一条数据
          }, 2000);
        },
        caseid(id){
          console.info("点击的id",id)
          this.$http.get('/api/article_info/articleinfo/getArticleBycascadeIdAndNum',
            {params:{cascadeId:id,num:this.count}}).then(res =>{
            console.info("获取的子栏目文章=>",res.data.data)
            this.list= res.data.data;
          })
        },
  }
</script>
​
<style second>
 .e-left-img{
    display: flex;
    width: 100%;
    flex-direction: column;
  }
  .e-con{
    display: flex;
    width: 100%;
  }
  .e-con img{
    width: 50%;
    height: 230px;
​
  }
  .e-left-content{
    display: flex;
    width: 50%;
    margin: 0 50px;
    margin-right: 0px;
    flex-direction: column;
  }
  .e-left-content span{
    font-size: 20px;
    font-weight: bold;
    overflow: hidden;
    -webkit-line-clamp: 1;
    text-overflow: ellipsis;
    display: -webkit-box;
    -webkit-box-orient: vertical;
  }
  .e-left-content p{
    text-indent:1em;
    font-size: 20px;
    color: #afb5b1;
    line-height: 2;
    overflow: hidden;
    -webkit-line-clamp: 4;
    text-overflow: ellipsis;
    display: -webkit-box;
    -webkit-box-orient: vertical;
  }
</style>
​
​
```

| **参数**                      | **说明**                                                   | **类型**    | **可选值** | **默认值** |
| ------------------------------- | ------------------------------------------------------------ | ------------- | ------------ | ------------ |
| **infinite-scroll-disabled**  | **是否禁用**                                               | **boolean** | **-**      | **false**  |
| **infinite-scroll-delay**     | **节流时延，单位为ms**                                     | **number**  | **-**      | **200**    |
| **infinite-scroll-distance**  | **触发加载的距离阈值，单位为px**                           | **number**  | **-**      | **0**      |
| **infinite-scroll-immediate** | **是否立即执行加载方法，以防初始状态下内容无法撑满容器。** | **boolean** | **-**      | **true**   |

****问题：在Vue里面使用mint-ui的**`Infinite scroll`**无线滚动，按照配置写完之后，发现控制台里报错了****

```
Error in directive infinite-scroll inserted hook: "TypeError: Failed to execute 'observe' on 'MutationObserver': parameter 1 is not of type 'Node'."
```

****解决******：给使用这个组件的元素设置**`height`**和**`overflow`

```
<div class="e-left-img"
    v-infinite-scroll="load"
    infinite-scroll-disabled="disabled"
    style="overflow:auto;height: 1361px">
```

