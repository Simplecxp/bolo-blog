title: vue使用swiper
date: '2021-07-04 00:47:00'
updated: '2021-07-04 00:47:00'
tags: [vue, swiper]
permalink: /articles/2021/07/04/1625330820090.html
---
# 安装

`npm install swiper vue-awesome-swiper --save`

卸载

```
npm uninstall swiper
```

**main.js**

```
import Vue from 'vue'
import VueAwesomeSwiper from 'vue-awesome-swiper'
 
// import style
import 'swiper/css/swiper.css'
 
Vue.use(VueAwesomeSwiper, /* { default options with global component } */)
```

**or**

```
import { Swiper, SwiperSlide } from 'vue-awesome-swiper'
import 'swiper/css/swiper.css'
```

**问题**

**1. This dependency was not found:**

```
This dependency was not found:
```

解决：
因为引入scss文件报错，就是style加上lang scss就不行了。

解决思路：

```
npm install sass-loader --save;
npm install node-sass --save;
```

然后运行npm run dev

**2. Module build failed: TypeError: this.getOptions is not a function**

**说白了就是版本问题**
（Module build failed: TypeError: this.getOptions is not a function ）

这个问题主要是因为node-loader版本过高导致的问题，尝试将版本降低到@7.3.1

直接使用命令：

```
npm install sass-loader@7.3.1 --save-dev   降低版本号
```

**再进行npm run dev即可运行**

未解决，并且继续抛出异常（**Node Sass version 5.0.0 is incompatible with ^4.0.0**）

就是说@5.0.0版本过高了，需要换成@4.x版本的

降版本到@4.14.1

```
npm install node-sass@4.14.1 --save-dev
```

轮播图

```
<template>
  <div class="thumb-example">
    <!-- swiper1 -->
    <swiper class="swiper gallery-top" :options="swiperOptionTop" ref="swiperTop">
      <swiper-slide class="slide-1"></swiper-slide>
      <swiper-slide class="slide-2"></swiper-slide>
      <swiper-slide class="slide-3"></swiper-slide>
      <swiper-slide class="slide-4"></swiper-slide>
      <swiper-slide class="slide-5"></swiper-slide>
      <div class="swiper-button-next swiper-button-white" slot="button-next"></div>
      <div class="swiper-button-prev swiper-button-white" slot="button-prev"></div>
    </swiper>
    <!-- swiper2 Thumbs -->
    <swiper class="swiper gallery-thumbs" :options="swiperOptionThumbs" ref="swiperThumbs">
      <swiper-slide class="slide-1"></swiper-slide>
      <swiper-slide class="slide-2"></swiper-slide>
      <swiper-slide class="slide-3"></swiper-slide>
      <swiper-slide class="slide-4"></swiper-slide>
      <swiper-slide class="slide-5"></swiper-slide>
    </swiper>
  </div>
</template>

<script>
  import { Swiper, SwiperSlide } from 'vue-awesome-swiper'
  import 'swiper/css/swiper.css'

  export default {
    name: 'swiper-example-thumbs-gallery',
    title: 'Thumbs gallery with Two-way control',
    components: {
      Swiper,
      SwiperSlide
    },
    data() {
      return {
        swiperOptionTop: {
          loop: true,
          loopedSlides: 5, // looped slides should be the same
          spaceBetween: 10,
          navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev'
          }
        },
        swiperOptionThumbs: {
          loop: true,
          loopedSlides: 5, // looped slides should be the same
          spaceBetween: 10,
          centeredSlides: true,
          slidesPerView: 'auto',
          touchRatio: 0.2,
          slideToClickedSlide: true
        }
      }
    },
    mounted() {
      this.$nextTick(() => {
        const swiperTop = this.$refs.swiperTop.$swiper
        const swiperThumbs = this.$refs.swiperThumbs.$swiper
        swiperTop.controller.control = swiperThumbs
        swiperThumbs.controller.control = swiperTop
      })
    }
  }
</script>

<style lang="scss" scoped>
  .thumb-example {
    height: 480px;
    background-color: black;
  }

  .swiper {
    .swiper-slide {
      background-size: cover;
      background-position: center;

      &.slide-1 {
        background-image:url('/static/image/Fttd1vWWwjEx9ZxYGq7BOAeez3jA.jpg');
      }
      &.slide-2 {
        background-image:url('/static/image/Flode7CpFCo3QnZli-CjOqjeoevX.jpg');
      }
      &.slide-3 {
        background-image:url('/static/image/Fn2gus86B4nzmDz-g-TFvEw3v6w2.jpg');
      }
      &.slide-4 {
        background-image:url('/static/image/Fr9uMkJReXv-E2uzTXETOTAUsHXO.jpg');
      }
      &.slide-5 {
        background-image:url('/static/image/Fr9uMkJReXv-E2uzTXETOTAUsHXO.jpg');
      }
    }

    &.gallery-top {
      height: 80%;
      width: 100%;
    }
    &.gallery-thumbs {
      height: 20%;
      box-sizing: border-box;
      padding:  0;
    }
    &.gallery-thumbs .swiper-slide {
      width: 25%;
      height: 100%;
      opacity: 0.4;
    }
    &.gallery-thumbs .swiper-slide-active {
      opacity: 1;
    }
  }
</style>
```

效果图

![image.png](https://b3logfile.com/file/2021/07/image-b5ae7ced.png)

