title: Redis
date: '2021-06-01 21:13:00'
updated: '2021-08-19 20:37:15'
tags: [Redis]
permalink: /articles/2021/06/21/1624281205300.html
---
1. **什么是Redis数据库?**
   Redis是一个完全开源的高性能的key-value数据库
2. **数据库**
   1. **关系型数据库**
      例如：oracle	mysql	SQLserver
      关系型数据库是指采用了关系模型来组织数据的数据库
      以行和列的形式存储数据，一便于用户理解
   2. **关系型数据库特性**
      1. 关系型数据库，是采用了关系模型来组织数据的
      2. 最大的特点是事务的一致性
      3. 简单来说，关系模型就是二维的表格模型
      4. 而一个关系型数据库就是有二维表以及之间的联系所组成的一个数据组织
   3. **关系型数据库的优点：**
      1. 二维表符合逻辑，容易理解，其关系模型相对网状和层次等其他关系模型更加容易理解
      2. 使用方便，SQL语言让操作的关系型更加方便
      3. 易于维护
   4. **缺点**
      1. 固定的表结构
      2. 高并发的读写需求
      3. 海量数据的高效率读写
   5. **非关系型数据库**
      1. 常见 非关系型数据库：Redis  MongoDb
      2. 非关系型数据库可以为大数据建立快速，可扩展的存储库
      3. 为了解决大规模数据集合多重数据种类带来的挑战
   6. **非关系数据库的特性**
      1. 使用了键值对的形式存储数据
      2. 非关系型数据库严格来说不是一种数据库，应该是一种数据库结构化的存储方式的集合
   7. **非关系数据库的优点**
      1. 无需经过SQL层的解析，镀锡性能很高
      2. 基于键值对，数据没有耦合性，容易扩展
      3. 存储数据的格式：
         1. nosql的存储格式是 key-value 形式 可以存取文档，图片等
         2. 关系型数据库只能支持基本类型
      4. 处理高并发，大批量数据的能力强
   8. **非关系数据库的缺点**
      1. 不提供SQL，学习较难
      2. 事务处理能力弱
      3. 没有完整的约束，对于复杂业务场景支持差
3. **Redis支持的数据类型**
   1. Redis通常被称为数据结构服务器，因为我们 value可以是
      1. **字符串（string）**
         * String是Redis最基本的类型
         * String是二进制安全的，可以包含任何数据，比如图片或者序列化的对象
         * String类型，一个键最大能存储512MB
      2. **哈希（hash/map）**
         * Redis Hash 是一个键值对集合
         * 是一个String类型的映射表，hash特别适合用于存储对象
         * ```
           D:\HelloWorld\redis\5.0.10\Redis-x64-5.0.10>redis-cli.exe -h 127.0.0.1 -p 6379
           127.0.0.1:6379> HMSET user username "zhansan" usercode "123"
           OK
           127.0.0.1:6379> HGETALL user
           1) "username"
           2) "zhansan"
           3) "usercode"
           4) "123"
           127.0.0.1:6379>
           ```
         * 
      3. **列表（list）**
         * Redis列表是一个简单的字符串列表，按照插入顺序排序
         * ```
           127.0.0.1:6379> LPUSH userlist zhangsan
           (integer) 1
           127.0.0.1:6379> LPUSH userlist lisi
           (integer) 2
           127.0.0.1:6379> LPUSH userlist ww
           (integer) 3
           127.0.0.1:6379> LRANGE userlist 0 10
           1) "ww"
           2) "lisi"
           3) "zhangsan"
           ```
         * 
      4. **集合（sets）**
         * Redis 的set是String类型 的无序集合
         * Redis中集合时通过哈希表实现的，所以添加，删除，查找都很简单
         * ```
           127.0.0.1:6379> SADD nameSet "aaa"
           (integer) 1
           127.0.0.1:6379> SADD nameSet "ccc"
           (integer) 1
           127.0.0.1:6379> SADD nameSet "bbb"
           (integer) 1
           127.0.0.1:6379> SMEMBERS nameSet
           1) "bbb"
           2) "ccc"
           3) "aaa"
           ```
      5. **有序集合（sorted sets）**
         * 有序集合 和我们set一样是String类型的集合
         * 不允许有重复的成员
         * 关联一个double类型的分数，然后通过分数来为Redis中的集合成员进行从小到大的排列
         * ```
           127.0.0.1:6379> ZADD list 1 qwe
           (integer) 1
           127.0.0.1:6379> ZADD list 2 asd
           (integer) 1
           127.0.0.1:6379> ZADD list 3 zxc
           (integer) 1
           127.0.0.1:6379> ZRANGE list 0 10
           1) "qwe"
           2) "asd"
           3) "zxc"
           ```
         * 

**redis命令**

1. set userName zhangsan 存值
2. get userName 读值
3. keys * 查看所有key
4. del userName 删除key
5. ttl name 以秒为单位返回key剩余的时间
   1. 返回 - 1 代表一直存在
   2. 返回 -2 ：已过期（不可用）
   3. expire userName 60 设置key的过期时间，key 过期后将不可用，单位: s
   4. exists username 检查key 是否存在 1：存在   0：不存在

打开一个 **cmd** 窗口 使用 cd 命令切换目录到 **C:\redis** 运行：

```
redis-server.exe redis.windows.conf
```

可以把 redis 的路径加到系统的环境变量里，这样就省得再输路径了，后面的那个 redis.windows.conf 可以省略，如果省略，会启用默认的。

这时候另启一个 cmd 窗口，原来的不要关闭，不然就无法访问服务端了。

切换到 redis 目录下运行:

```
redis-cli.exe -h 127.0.0.1 -p 6379
```

设置键值对:

```
set myKey abc
```

取出键值对:

```
get myKey
```

