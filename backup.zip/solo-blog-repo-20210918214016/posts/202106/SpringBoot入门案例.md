title: Spring Boot入门案例
date: '2021-06-01 21:13:00'
updated: '2021-08-19 20:36:00'
tags: [SpringBoot]
permalink: /articles/2021/06/21/1624282068718.html
---
## 2.1第一个SpringBoot项目

### 2.1.1步骤

项目名称：001-springboot-first

**（1） 创建一个Module，选择类型为Spring Initializr 快速构建**

![springboot01.png](https://b3logfile.com/file/2021/06/springboot01-b8c81068.png)

**（2）设置GAV坐标及pom配置信息**

![springboot02.png](https://b3logfile.com/file/2021/06/springboot02-d0168441.png)

**（3） 选择Spring Boot版本及依赖**

会根据选择的依赖自动添加起步依赖并进行自动配置

![springboot03.png](https://b3logfile.com/file/2021/06/springboot03-940899aa.png)

**（4） 设置模块名称、Content Root 路径及模块文件的目录**

![springboot04.png](https://b3logfile.com/file/2021/06/springboot04-5201defc.png)

> 点击 Finish，如果是第一次创建，在右下角会提示正在下载相关的依赖

**（5） 项目创建完毕，如下**

![springboot05.png](https://b3logfile.com/file/2021/06/springboot05-48819acc.png)

**（6） 项目结构**

![springboot06.png](https://b3logfile.com/file/2021/06/springboot06-f56e589e.png)

static：存放静态资源，如图片、CSS、JavaScript 等

templates：存放 Web 页面的模板文件

application.properties/application.yml 用于存放程序的各种依赖模块的配置信息，比如 服务端口，数据库连接配置等

**对 SpringBoot 项目结构进行说明**

➢ .mvn|mvnw|mvnw.cmd：使用脚本操作执行 maven 相关命令，国内使用较少，可删除

➢ .gitignore：使用版本控制工具 git 的时候，设置一些忽略提交的内容

➢ static|templates：后面模板技术中存放文件的目录

➢ application.properties：SpringBoot 的配置文件，很多集成的配置都可以在该文件中进行配置，例如：Spring、springMVC、Mybatis、Redis 等。

```
目前是空的
```

➢ Application.java：SpringBoot 程序执行的入口，执行该程序中的 main 方法，SpringBoot就启动了

### 2.1.2对 POM.xml文件进行解释

```
<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 https://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>
    <!--继承 SpringBoot 框架的一个父项目，所有自己开发的 Spring Boot 都必须的继承-->
    <parent>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-parent</artifactId>
        <version>2.4.2</version>
        <relativePath/> <!-- lookup parent from repository -->
    </parent>
    <!--当前项目的 GAV 坐标-->
    <groupId>com.abc.springboot</groupId>
    <artifactId>001-springboot-first</artifactId>
    <version>0.0.1-SNAPSHOT</version>
    <!--maven 项目名称，可以删除-->
    <name>001-springboot-first</name>
    <!--maven 项目描述，可以删除-->
    <description>Demo project for Spring Boot</description>
    <!--maven 属性配置，可以在其它地方通过${}方式进行引用-->
    <properties>
        <java.version>1.8</java.version>
    </properties>
    <dependencies>
        <!--SpringBoot 框架 web 项目起步依赖，通过该依赖自动关联其它依赖，不需要我们一个一个去添加了-->
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-web</artifactId>
        </dependency>
​
        <!--SpringBoot 框架的测试起步依赖，例如：junit 测试，如果不需要的话可以删除-->
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-test</artifactId>
            <scope>test</scope>
        </dependency>
    </dependencies>
​
    <build>
        <plugins>
            <!--SpringBoot 提供的打包编译等插件-->
            <plugin>
                <groupId>org.springframework.boot</groupId>
                <artifactId>spring-boot-maven-plugin</artifactId>
            </plugin>
        </plugins>
    </build>
​
</project>
​
```

### 2.1.3创建一个 Spring MVC 的 Spring BootController

SpringBootController 类所在包：com.abc.springboot.controller

```
package com.abc.springboot.controller;
​
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
​
@Controller
public class SpringBootController {
    @RequestMapping( "/springBoot/say")
    public @ResponseBody String say() {
        return "Hello,springBoot!";
    }
}
​
```

**注意：新创建的类一定要位于 Application 同级目录或者下级目录，否则 SpringBoot 加载不到。**

### 2.1.4在 IDEA 中右键，运行 Application 类中的 main 方法

通过在控制台的输出，可以看到启动 SpringBoot 框架，会启动一个内嵌的 tomcat，端口号为 8080，上下文根为空

> Tomcat started on port(s): 8080 (http) with context path ''

### 2.1.5在浏览器中输入 [http://localhost:8080/springBoot/say](http://localhost:8080/springBoot/say) 访问

![springboot07.png](https://b3logfile.com/file/2021/06/springboot07-8bb2ad99.png)

## 2.2入门案例分析

Spring Boot 的父级依赖 spring-boot-starter-parent 配置之后，当前的项目就是 Spring Boot 项目

➢ spring-boot-starter-parent 是一个 Springboot 的父级依赖，开发 SpringBoot 程序都需要继承该父级项目，它用来提供相关的 Maven 默认依赖，使用它之	        	后，常用的 jar包依赖可以省去 version 配置

➢ Spring Boot 提供了哪些默认 jar 包的依赖，可查看该父级依赖的 pom 文件

➢ 如果不想使用某个默认的依赖版本，可以通过 pom.xml 文件的属性配置覆盖各个依赖项，比如覆盖 Spring 版本

```
<properties>
<spring-framework.version>5.0.0.RELEASE</ spring-framework.version >
​
</properties>
```

**@SpringBootApplication 注解是 Spring Boot 项目的核心注解，主要作用是开启Spring 自动配置，如果在 Application 类上去掉该注解，那么不会启动 SpringBoot程序**

➢ main 方法是一个标准的 Java 程序的 main 方法，主要作用是作为项目启动运行的入口

➢ @Controller 及 @ResponseBody 依然是我们之前的 Spring MVC，因为 Spring Boot的里面依然是使用我们的 Spring MVC + Spring + MyBatis 等框架

## 2.3Spring Boot 的核心配置文件

Spring Boot 的核心配置文件用于配置 Spring Boot 程序，名字必须以 application 开始

### 2.3.1 核心配置格式

#### **（1） .properties 文件（默认采用该文件）**

```
在001-springboot-first项目基础上，进行修改
```

通过修改 application.properties 配置文件，在修改默认 tomcat 端口号及项目上下文件根键值对的 properties 属性文件配置方式

```
#设置内嵌 Tomcat 端口号
server.port=9090
#配置项目上下文根
server.servlet.context-path=/001-springboot-first
​
​
控制台显示
Tomcat initialized with port(s): 9090 (http)
Tomcat started on port(s): 9090 (http) with context path '/001-springboot-first'
```

页面显示

![springboot08.png](https://b3logfile.com/file/2021/06/springboot08-4a277950.png)

#### （2） .yml 文件

yml 是一种 yaml 格式的配置文件，主要采用一定的空格、换行等格式排版进行配置。

yaml 是一种直观的能够被计算机识别的的数据序列化格式，容易被人类阅读，yaml 类似于 xml，但是语法比 xml 简洁很多，值与前面的冒号配置项必须要有一个空格， yml 后缀也可以使用 yaml 后缀

```
#设置内嵌 Tomcat 端口号
server:
  port: 9090
#配置项目上下文根
  servlet:
    context-path: /001-springboot-first
```

**注意：当两种格式配置文件同时存在，使用的是.properties 配置文件，为了演示 yml，可以先将其改名，重新运行 Application，查看启动的端口及上下文根**

### 2.3.2 多环境配置

在实际开发的过程中，我们的项目会经历很多的阶段（开发->测试->上线），每个阶段的配置也会不同，例如：端口、上下文根、数据库等，那么这个时候为了方便在不同的环境之间切换，SpringBoot 提供了多环境配置，具体步骤如下:

#### （1）properties环境配置

**为每个环境创建一个配置文件，命名必须以 application-环境标识.properties|yml**

application-dev.properties

```
##开发环境
##设置内嵌 Tomcat 默认端口号
server.port=8080
#设置项目的上下文根
server.servlet.context-path=/001-springboot-first-dev
```

application-product.properties

```
##生产环境
##配置内嵌 Tomcat 默认端口号
server.port=80
##配置项目上下文根
server.servlet.context-path=/001-springboot-first-product
```

application-test.properties

```
##测试环境
##配置内嵌 Tomcat 端口号
server.port=8081
##配置项目的上下文根
server.servlet.context-path=/001-springboot-first-test
```

**在总配置文件 application.properties 进行环境的激活**

```
#SpringBoot 的总配置文件
#激活开发环境
#spring.profiles.active=dev
#激活测试环境
#spring.profiles.active=test
#激活生产环境
spring.profiles.active=product
```

等号右边的值和配置文件的环境标识名一致，可以更改总配置文件的配置，重新运行 Application，查看启动的端口及上下文根

#### （2）yml环境配置

**为每个环境创建一个配置文件，命名必须以 application-环境标识.properties|yml**

SpringBoot 总配置文件：application.yml

```
#springboot 总配置文件
#激活开发环境
#spring:
# profiles:
# active: dev
#激活测试环境
#spring:
# profiles:
# active: test
#激活生产环境
spring:
 profiles:
 active: product
```

开发环境配置文件：application-dev.yml

```
#设置开发环境配置
server:
 port: 8080 #设置 Tomcat 内嵌端口号
 servlet:
 context-path: /dev #设置上下文根
```

测试环境配置文件：application-test.yml

```
#设置测试环境配置
server:
 port: 9090
 servlet:
 context-path: /test
```

生产环境配置文件：application-product.yml

```
#设置生产环境配置
server:
 port: 80
 servlet:
 context-path: /product
```

### 2.3.3 Spring Boot 自定义配置

在 SpringBoot 的核心配置文件中，除了使用内置的配置项之外，我们还可以在自定义配置，然后采用如下注解去读取配置的属性值

#### **@Value** 注解

用于逐个读取 application.properties 中的配置

**案例演示**

在核心配置文件 applicatin.properties 中，添加两个自定义配置项 school.name 和website。

在 IDEA 中可以看到这两个属性不能被 SpringBoot 识别，背景是桔色的

```
school.name=abc
school.websit=www.baidu.com
```

application.yml 格式配置文件

```
#设置端口号及上下文根
server:
 port: 9090
 servlet:
 context-path: /
school:
 name: ssm
websit: http://www.baidu.com
```

在 SpringBootController 中定义属性，并使用@Value 注解或者自定义配置值，并对其方法进行测试

```
@Controller
public class SpringBootController {
 @Value("${school.name}")
 private String schoolName;
 @Value("${websit}")
 private String websit;
 @RequestMapping(value = "/springBoot/say")
 public @ResponseBody String say() {
 return schoolName + "------" + websit;
 }
}
```

重新运行 Application，在浏览器中进行测试

![springboot09.png](https://b3logfile.com/file/2021/06/springboot09-0f9243ef.png)

#### **@ConfigurationProperties**

将整个文件映射成一个对象，用于自定义配置项比较多的情况

**案例演示**

➢ 在 com.abc.springboot.config 包下创建 ConfigInfo 类，并为该类加上 Component 和ConfigurationProperties 注解，并在 ConfigurationProperties 注解中添加属性 prefix，作用可以区分同名配置

```
package com.abc.springboot.config;
​
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;
​
@Component
@ConfigurationProperties(prefix = "school")
public class ConfigInfo {
    private String name;
    private String websit;
​
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getWebsit() {
        return websit;
    }
    public void setWebsit(String websit) {
        this.websit = websit;
    }
}
```

application.properties 配置文件

```
#设置内嵌 Tomcat 端口号
server.port=9090
#设置上下文根
server.servlet.context-path=/config
school.name=ssm
school.websit=http://www.baidu.com
```

application.yml 配置文件

```
server:
 port: 9090
 servlet:
 context-path: /config
 
school:
 name: ABC
 websit: http://www.baidu.com
```

在 SpringBootController 中注入 ConfigInfo 配置类

```
//注入 ConfigInfo 配置类
    @Autowired
    private ConfigInfo configInfo;
​
    @RequestMapping( "/springBoot/config")
    public @ResponseBody String config() {
        return configInfo.getName() + "=======" + configInfo.getWebsit();
    }
​
```

重新运行 Application，在浏览器中进行测试

![springboot10.png](https://b3logfile.com/file/2021/06/springboot10-7306037b.png)

**中文乱码**

如果在 SpringBoot 核心配置文件中有中文信息，会出现乱码：

◼ 一般在配置文件中，不建议出现中文（注释除外）

◼ 如果有，可以先转化为 ASCII 码

**如果是从其它地方拷贝的配置文件，一定要将里面的空格删干净**

## 2.4Spring Boot 前端使用 JSP

#### **2.4.1** **在** **pom.xml** **文件中配置以下依赖项**

```
<!--引入 Spring Boot 内嵌的 Tomcat 对 JSP 的解析包，不加解析不了 jsp 页面-->
<!--如果只是使用 JSP 页面，可以只添加该依赖-->
<dependency>
 <groupId>org.apache.tomcat.embed</groupId>
 <artifactId>tomcat-embed-jasper</artifactId>
</dependency>
<!--如果要使用 servlet 必须添加该以下两个依赖-->
<!-- servlet 依赖的 jar 包-->
<dependency>
 <groupId>javax.servlet</groupId>
 <artifactId>javax.servlet-api</artifactId>
</dependency>
<dependency>
 <groupId>javax.servlet.jsp</groupId>
 <artifactId>javax.servlet.jsp-api</artifactId>
 <version>2.3.1</version>
</dependency>
<!--如果使用 JSTL 必须添加该依赖-->
<!--jstl 标签依赖的 jar 包 start-->
<dependency>
 <groupId>javax.servlet</groupId>
 <artifactId>jstl</artifactId>
</dependency>
```

#### 2.4.2在 pom.xml 的 build 标签中要配置以下信息

SpringBoot 要求 jsp 文件必须编译到指定的 META-INF/resources 目录下才能访问，否则访问不到。其实官方已经更建议使用模板技术（后面会讲模板技术）

```
<!--
 SpringBoot 要求 jsp 文件必须编译到指定的 META-INF/resources 目录下才能访问，否则访问
不到。
 其它官方已经建议使用模版技术（后面会课程会单独讲解模版技术）
-->
<resources>
 <resource>
 <!--源文件位置-->
 <directory>src/main/webapp</directory>
 <!--指定编译到 META-INF/resources，该目录不能随便写-->
 <targetPath>META-INF/resources</targetPath>
 <!--指定要把哪些文件编译进去，**表示 webapp 目录及子目录，*.*表示所有文件-->
 <includes>
 <include>**/*.*</include>
 </includes>
 </resource>
</resources>
```

#### 2.4.3配置jsp

在 application.properties 文件配置 Spring MVC 的视图展示为jsp，这里相当于 Spring MVC 的配置

```
#SpringBoot 核心配置文件
#指定内嵌 Tomcat 端口号
server.port=8080
#配置 SpringMVC 视图解析器
#其中：/ 表示目录为 src/main/webapp
spring.mvc.view.prefix=/
spring.mvc.view.suffix=.jsp
```

**集成完毕之后，剩下的步骤和Spring MVC 一样**

application.yml 格式的配置文件

```
#SpringBoot 核心配置文件
#指定内嵌 Tomcat 端口号
server:
 port: 8080
 servlet:
 context-path: /
#配置 SpringMVC 视图解析器
#其中：/ 表示目录为 src/main/webapp
spring:
 mvc:
 view:
 prefix: /
 suffix: .jsp
```

#### 2.4.4创建 JspController 类

在 com.abc.springboot.controller 包下创建 JspController 类，并编写代码

```
@Controller
public class SpringBootController {
 @RequestMapping(value = "/springBoot/jsp")
 public String jsp(Model model) {
 model.addAttribute("data","SpringBoot 前端使用 JSP 页面！");
 return "index";
 } }
```

#### 2.4.5新建index.jsp 页面

在 src/main 下创建一个 webapp 目录，然后在该目录下新建index.jsp 页面

如果在webapp目录下右键，没有创建jsp的选项，可以在Project Structure中指定webapp为 Web Resource Directory

#### 2.4.6在 jsp 中获取 Controller 传递过来的数据

```
​
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>Title</title>
</head>
<body>
      ${data}
</body>
</html>
​
```

#### 2.4.7重新运行 Application，通过浏览器访问测试![springboot11.png](https://b3logfile.com/file/2021/06/springboot11-5b4b4d31.png)

