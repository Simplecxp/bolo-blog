title: Vue 导航栏固定在顶部，监听滚动事件
date: '2021-08-18 00:22:44'
updated: '2021-08-18 00:22:44'
tags: [vue]
permalink: /articles/2021/08/18/1629217364923.html
---
滚动之前
![image.png](https://b3logfile.com/file/2021/08/image-ad223521.png)


滚动之后

![image.png](https://b3logfile.com/file/2021/08/image-05ac3e37.png)

**1.固定二级分类标题导航栏**

```
​
<hr style="background-color:#2059a1; width: 100%;height: 1px;">
<div class="header-main" :style="getColor()">
    <el-button @click="caseid(item.id)"  
                :style="getColor()" v-for="(item,index) in guanzhuList.slice(3,10)" 
                :key="index" 
                :class="{active: active == 0}">
        {{item.cascadeName}}
    </el-button>
</div>
<hr style="background-color:#2059a1; width: 100%;height: 1px;">
​
```

**	****css**

```
​
  .header-main{
    display: flex;
    background:rgba(255, 255, 255, 0.15);
    position: sticky;
    top:0;
    justify-content: space-around;
  }
  .el-button{
    border: 0px solid #DCDFE6;
    border-radius: 0px;
  }
```

**2.监听滚动事件******handleScroll()****

```
handleScroll () {
    const scrollTop = document.documentElement.scrollTop || document.body.scrollTop//获取滚动距离
    this.scrollTop = scrollTop//data里return了一个全局的scrollTop
    console.log(scrollTop)
},
```

**3.顶部导航栏滚动下去时改变导航栏背景色，给导航栏添加动态的style样式**`<div class="header-main" :style="getColor()">`

```
getColor(){
    //当滚动距离超过导航栏高度时改变背景色
    if(this.scrollTop > 1467){
    return {
        background:"#1b2cff",
        color:"#ffffff",
        'font-weight': "600",
        height:"60px",
       }
      }else{
        return false
      }
  },
```

**4.在mounted()中监听滚动事件**

```
mounted() {
    // 监听滚动事件
    // document.getElementById("blockmain").addEventListener("scroll", this.handleScroll)
    // window.addEventListener('scroll', this.handleScroll)
    this.$nextTick(function () {
      window.addEventListener('scroll', this.handleScroll)
    })
  },
```

**5.在组件销毁时需要移除滚动监听器，不然监听器会报错**

```
destroy() {
    // 必须移除监听器，不然当该vue组件被销毁了，监听器还在就会出错
    window.removeEventListener('scroll', this.handleScroll)
  }
```

