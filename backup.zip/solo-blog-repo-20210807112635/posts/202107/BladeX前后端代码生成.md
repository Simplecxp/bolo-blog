title: BladeX前后端代码生成
date: '2021-07-15 00:10:00'
updated: '2021-07-15 00:10:00'
tags: [vue, BladeX]
permalink: /articles/2021/07/15/1627661475200.html
---
**BladeX：**[https://bladex.vip/](https://bladex.vip/)

**Avue：**[https://avuejs.com/](https://avuejs.com/)

# **1.启动**

1. 启动redis`redis-server`
2. 使用idea启动bladex-boot后台框架
3. saber vue---`npm install`

# **2.代码生成**

驱动类:

```
com.mysql.cj.jdbc.Driver
```

连接地址:

```
jdbc:mysql://localhost:3306/相应数据库?useSSL=false&useUnicode=true&characterEncoding=utf-8&zeroDateTimeBehavior=convertToNull&transformedBitIsBoolean=true&serverTimezone=GMT%2B8&nullCatalogMeansCurrent=true&allowPublicKeyRetrieval=true
```

![设置数据库连接](https://b3logfile.com/file/2021/07/image-ebcac745.png)

![生成表](https://b3logfile.com/file/2021/07/image-6583b621.png)



