title: Springboot发送邮箱验证
date: '2021-06-22 21:13:00'
updated: '2021-06-21 21:58:55'
tags: [SpringBoot]
permalink: /articles/2021/06/21/1624283869066.html
---
**1.引入pom相关依赖**

```
<!--Redis-->
        <dependency>
            <groupId>redis.clients</groupId>
            <artifactId>jedis</artifactId>
            <version>2.1.0</version>
        </dependency>
        <dependency>
            <groupId>junit</groupId>
            <artifactId>junit</artifactId>
            <version>4.12</version>
            <scope>compile</scope>
        </dependency>

        <!--邮箱发送-->
        <dependency>
            <groupId>javax.mail</groupId>
            <artifactId>mail</artifactId>
            <version>1.4.7</version>
        </dependency>
        <dependency>
            <groupId>org.springframework</groupId>
            <artifactId>spring-context-support</artifactId>
            <version>4.1.7.RELEASE</version>
        </dependency>
```

**2.创建spring-email.xml**

```
<?xml version="1.0" encoding="UTF-8"?>
<beans xmlns="http://www.springframework.org/schema/beans"
       xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
       xsi:schemaLocation="http://www.springframework.org/schema/beans http://www.springframework.org/schema/beans/spring-beans.xsd">

    <bean id="mailSender" class="org.springframework.mail.javamail.JavaMailSenderImpl">
        <!--smtp:电子邮件传输的协议，用于信息传递和有关来信的通知-->
        <property name="host" value="smtp.qq.com"/>
        <!--编码格式-->
        <property name="defaultEncoding" value="utf-8"/>
        <property name="username" value="2877406366@qq.com"/>
        <property name="password" value="密码"/>
        <!--true : 代表需要的身份验证
            false：表示不需要身份验证
            -->
        <property name="javaMailProperties">
            <value>
                mail.smtp.auth=true
            </value>
        </property>
    </bean>
    <bean id="templateMessage" class="org.springframework.mail.SimpleMailMessage">
        <property name="from" value="2877406366@qq.com"/>
        <property name="subject" value="注册激活码"/>
    </bean>

    <bean id="orderMessage" class="com.cxp.EmailMessage">
        <property name="mailSender" ref="mailSender"/>
        <property name="simpleMailMessage" ref="templateMessage"/>
    </bean>
</beans>
```

**MD5**

```
package com.cxp;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Random;

public class MD5 {

	public static String getMd5(String plainText,int length) {
		try {
			MessageDigest md = MessageDigest.getInstance("MD5");
			md.update(plainText.getBytes());
			byte b[] = md.digest();

			int i;

			StringBuffer buf = new StringBuffer("");
			for (int offset = 0; offset < b.length; offset++) {
				i = b[offset];
				if (i < 0)
					i += 256;
				if (i < 16)
					buf.append("0");
				buf.append(Integer.toHexString(i));
			}
			// 32位
			// return buf.toString();
			// 16位
			// return buf.toString().substring(0, 16);

			return buf.toString().substring(0, length);
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
			return null;
		}

	}

	public static int getRandomCode(){
		int max=9999;
        int min=1111;
        Random random = new Random();
        return random.nextInt(max)%(max-min+1) + min;
	}
	public static void main(String[] args) {
		System.out.println(MD5.getMd5("helloadsfdsffsf",6));
		System.out.println(getRandomCode());
	}

}
```

EmailMessage

```
package com.cxp;

import org.springframework.mail.MailSender;
import org.springframework.mail.SimpleMailMessage;

/**
 * 用于邮箱发送
 */
public class EmailMessage {

    private MailSender mailSender;

    private SimpleMailMessage simpleMailMessage;


    public void setMailSender(MailSender mailSender) {
        this.mailSender = mailSender;
    }

    public void setSimpleMailMessage(SimpleMailMessage simpleMailMessage) {
        this.simpleMailMessage = simpleMailMessage;
    }

    /**
     * 邮件发送
     * @param userCode  用户账号
     * @param activaCode 激活码
     */
    public void placeOrder(String userCode,String activaCode){
        //只能用来发送文本格式的邮件
        SimpleMailMessage simpleMailMessage=new SimpleMailMessage(this.simpleMailMessage);
        simpleMailMessage.setTo(userCode);//发送给用户的邮箱
        simpleMailMessage.setText("您好！\n" +
                "您正在申请发送验证码：\n" +
                "为了账号安全，请在指定位置输入下列验证码： "+activaCode+"。 验证码涉及个人账号隐私安全，切勿向他人透漏。：");//发送的内容是激活码
        this.mailSender.send(simpleMailMessage);//发送邮件

    }
}
```

EmailTest

```
package com.cxp;

import org.junit.Test;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.Date;

public class EmailTest {

    @Test
    public void emailTest(){
        //1.用户的添加方法
        System.out.println("用户添加");
        //2.生成激活码（根据时间，随机数）
        String activationCode = MD5.getMd5(new Date().toLocaleString(),32);
        System.out.println("激活码===》"+activationCode);
        //3.发送邮箱
        ClassPathXmlApplicationContext email=new ClassPathXmlApplicationContext("spring-email.xml");
        EmailMessage message= (EmailMessage) email.getBean("orderMessage");
        message.placeOrder("2877406366@qq.com",activationCode);
        //4.激活码存入到Redis（具有过期时间的set）
        ClassPathXmlApplicationContext atx=new ClassPathXmlApplicationContext("spring-redis.xml");
        RedisAPI api =(RedisAPI) atx.getBean("redisAPI");
        api.set("action",30*60,activationCode);
    }
}
```

