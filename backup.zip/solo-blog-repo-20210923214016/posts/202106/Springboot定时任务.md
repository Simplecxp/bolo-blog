title: Springboot定时任务
date: '2021-06-21 21:13:00'
updated: '2021-08-19 20:34:04'
tags: [SpringBoot]
permalink: /articles/2021/06/21/1624282736273.html
---
# **定时任务**

```
//开启定时任务
@EnableScheduling
public class StudySpringBootApplication {
```

**写代码**

```
package com.abc.studyspringboot.schedule;
​
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
​
import java.util.Date;
​
@Component
public class MyTask {
​
    //方法结束计时
    /*@Scheduled(fixedDelay = 3000)
    public void task1(){
        try {
            Thread.sleep(1000);
        }catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("fixed---->123"+new Date());
    }*/
​
    //方法开始计时
    /*@Scheduled(fixedRate = 3000)
    public void task2(){
        try {
            Thread.sleep(1000);
        }catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("fixed---->123"+new Date());
    }*/
​
    //cron支持表达式
    /*@Scheduled(cron = "2,4,10,12,22,34,45,56 * * * * *")
    public void task3(){
        try {
            Thread.sleep(1000);
        }catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("fixed---->123"+new Date());
    }*/
​
    //周期性每五秒执行一次
    //@Scheduled(cron = "*/5 * * * * *")
    //public void task4(){
    //    System.out.println("fixed---->123"+new Date());
    //}
​
    //每天17:22执行
    @Scheduled(cron = "0 22 17 * * *")
    public void task4(){
        System.out.println("fixed---->123"+new Date());
    }
}
​
```

结果：fixed---->123Sun Jan 31 17:22:00 CST 2021

**区别**

1. fixedDelay控制方法执行的间隔时间，是以上一次方法执行完开始算起，如上一次方法执行阻塞住了，那么直到上一次执行完，并间隔给定的时间后，执行下一次。
2. fixedRate是按照一定的速率执行，是从上一次方法执行开始的时间算起，如果上一次方法阻塞住了，下一次也是不会执行，但是在阻塞这段时间内累计应该执行的次数，当不再阻塞时，一下子把这些全部执行掉，而后再按照固定速率继续执行。
3. cron表达式可以定制化执行任务，但是执行的方式是与fixedDelay相近的，也是会按照上一次方法结束时间开始算起。
4. initialDelay 。如： @Scheduled(initialDelay = 10000,fixedRate = 15000 这个定时器就是在上一个的基础上加了一个initialDelay = 10000 意思就是在容器启动后,延迟10秒后再执行一次定时器,以后每15秒再执行一次该定时器

