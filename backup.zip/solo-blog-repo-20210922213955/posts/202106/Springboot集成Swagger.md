title: Spring boot集成Swagger
date: '2021-06-06 21:13:00'
updated: '2021-08-19 20:34:49'
tags: [Swagger, SpringBoot]
permalink: /articles/2021/06/21/1624282665733.html
---
**引入依赖**

```
<!--集成Swagger
        引入swagger包
        -->
        <dependency>
            <groupId>io.springfox</groupId>
            <artifactId>springfox-swagger2</artifactId>
            <version>2.9.2</version>
        </dependency>
        <dependency>
            <groupId>io.springfox</groupId>
            <artifactId>springfox-swagger-ui</artifactId>
            <version>2.9.2</version>
        </dependency>
```

**写配置**

```
package com.abc.studyspringboot.config;
​
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;
​
@EnableSwagger2
@Configuration
public class SwaggerConfig {
    @Bean
    public Docket customDocket() {
        ApiInfo apiInfo =new ApiInfoBuilder()
                //文档说明
                .title("cxp测试专用")
                // 文档版本说明
                .version("1.0.0")
                .description("cxp学习测试专用")
                .license("Apache 2.0")
                .build();
        return new Docket(DocumentationType.SWAGGER_2)
                .apiInfo(apiInfo)
                .select()
                .apis(RequestHandlerSelectors.basePackage("com.abc.studyspringboot.controller"))
                .build();
    }
​
}
​
```

**测试**

```
package com.abc.studyspringboot.controller;
​
import com.abc.studyspringboot.pojo.Student;
import com.abc.studyspringboot.serives.StudentService;
import io.swagger.annotations.*;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
​
import javax.annotation.Resource;
import java.util.List;
​
@Controller
@RequestMapping("/stu")
@Api("与用户相关的API")
public class UserController {
​
    @Resource
    StudentService studentService;
​
   /* @GetMapping
    @ResponseBody
    public List<Student> getStu(){
        return studentService.queryStudentList();
    }*/
​
    @GetMapping("/{id}")
    @ResponseBody
    @ApiOperation("获取用户的信息的接口")
    @ApiImplicitParam(name="id",value = "用户的id",paramType = "path",defaultValue = "1")
    @ApiResponse(code = 200, message="用户的信息正确")
    public Student getStu(@PathVariable int id){
        System.out.println(123);
        return new Student(id,"ewq",22);
    }
​
    @PostMapping
    @ResponseBody
    @ApiImplicitParam(name = "student",value = "用户信息的对象",paramType = "body",dataTypeClass = com.abc.studyspringboot.pojo.Student.class)
    public String add(Student student){
        return "sucess";
    }
/*
    @PostMapping("/add")
    @ResponseBody
    @ApiOperation("多参数添加用户")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "name", value="姓名",dataType = "string",paramType = "query",defaultValue = "cxp"),
            @ApiImplicitParam(name = "age", value="年龄",dataType = "int",paramType = "query",defaultValue = "19")
    })
    @ApiResponses({
            @ApiResponse(code = 200, message="成功了"),
            @ApiResponse(code = 400, message="网页丢失了")
    })
    public String addstu(String name,int age){
        return "sucess";
    }*/
​
    @PutMapping
    @ResponseBody
    public String upd(Student student){
        return "sucess";
    }
​
    @DeleteMapping("/{id}")
    @ResponseBody
    public String del(@PathVariable int id){
        return "sucess";
    }
}
​
```

