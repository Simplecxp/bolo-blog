title: 预览PDF
date: '2021-08-19 20:20:45'
updated: '2021-08-19 20:28:35'
tags: [PDF]
permalink: /articles/2021/08/19/1629375645891.html
---
# PC端浏览器预览

只能在pc端预览，不支持移动端预览，可设置a标签给予下载操作

```
<body style="height: 100%; width: 100%; overflow: hidden; margin:0px; background-color: rgb(82, 86, 89);">
<object type="application/pdf" data="pdf文件" id="review" style="position:absolute; left: 0; top: 0;" width="100%" height="100%" >
    <a href="caoxupei.pdf">caoxupei.pdf</a>//手机端点击可下载
</object>
</body>
```

# 多端预览

用 pdf.js 只需要改一行代码，就可以实现多端手机网页全都适应。

系统中需要提供pdf预览的功能，在pc端可以使用浏览器直接打开，但在手机端浏览器不能直接打开

github地址：[https://github.com/EricerYang/dovePdf](https://github.com/EricerYang/dovePdf)
使用这个脚本可以在PC端和手机端打开pdf

在index.html中修改代码

```
<div id="tmPlayer" class="tmPlayer" style="width: 100%; height: 100%;"></div>
<script>
	/// var_filepath 里面写入服务器上pdf的地址，例如: https://er.com/mypdf
	var var_filepath = "http://localhost:63343/blogzz/pdf/caoxupei.pdf";
	$(".loadEffect").attr("style","display:none;");
	$('.tmPlayer').html('<iframe frameBorder="0" scrolling="no" src="./pdf/web/viewer.html?file=' + var_filepath +'" style="width: 100%;height: 100%;">');
</script>
```

